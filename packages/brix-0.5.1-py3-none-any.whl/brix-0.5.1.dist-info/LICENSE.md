This software framework is the property of QuantumBlack and the use of it
is governed by the terms of the license agreement between your organisation
and QuantumBlack. No part of it may be shown outside of your organisation,
including with outside software or consulting firms, without express prior
written consent of the Legal Department.

Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd.
All Rights Reserved.
