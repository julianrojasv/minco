# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa


import datetime
import os
import posixpath
from abc import abstractmethod, abstractproperty
from collections import OrderedDict
from enum import Enum
from urllib.parse import urlparse

from brix.post.post import KnowledgePost
from brix.postprocessors import KnowledgePostProcessor
from brix.utils.registry import SubclassRegisteringABCMeta

from . import config_defaults
from .config import KnowledgeRepositoryConfig


class KnowledgeRepository(metaclass=SubclassRegisteringABCMeta):
    _registry_keys = None

    class PostStatus(Enum):
        DRAFT = 0  # Post is still being written and not yet submitted
        SUBMITTED = 1  # Post is submitted and waiting for review
        UNPUBLISHED = 2  # Post is approved to publish, but not published
        PUBLISHED = 3  # Post is published and visible on /feed

    @classmethod
    def for_uri(cls, uri, *args, **kwargs):
        scheme = (
            urlparse(uri).scheme or "file"
        )  # returns empty string for filesystem uri
        return cls._get_subclass_for(scheme).from_uri(uri, *args, **kwargs)

    @classmethod
    def from_uri(cls, uri, *args, **kwargs):
        return cls(uri, *args, **kwargs)

    @classmethod
    def create_for_uri(cls, uri, config, **kwargs):
        scheme = (
            urlparse(uri).scheme or "file"
        )  # returns empty string for filesystem uri
        return cls._get_subclass_for(scheme).create(uri, config, **kwargs)

    @classmethod
    def create(cls, uri, config=None, **kwargs):
        raise NotImplementedError

    @classmethod
    def exists(cls, uri):
        scheme = (
            urlparse(uri).scheme or "file"
        )  # returns empty string for filesystem uri
        return cls._get_subclass_for(scheme).exists(uri)

    def __init__(self, uri, config=None, **kwargs):
        self.uri = uri
        self.config = KnowledgeRepositoryConfig(self)
        self.config.debug = False  # TODO: depricate
        self.config.update_defaults(config_defaults)
        if config:
            self.config.update(config)
        self.init(**kwargs)

    @property
    def config(self):
        return self._config

    @config.setter
    def config(self, config):
        assert isinstance(
            config, KnowledgeRepositoryConfig
        ), "`config` should be a `KnowledgeRepositoryConfig` instance."
        self._config = config

    @abstractmethod
    def update_config(self, conf):
        """
        Update and persist config.
        """
        raise NotImplementedError

    @property
    def uris(self):
        # uniform way of returning uris in the format expected by the app
        return {"": self.uri}

    @property
    def revisions(self):
        # uniform way of returning uri - revision mappings in the format expected by the app
        return {self.uri: self.revision}

    # ------------- Repository actions / state ------------------------------------

    def session_begin(self):
        pass

    def session_end(self):
        pass

    @abstractproperty
    def revision(self):
        raise NotImplementedError

    def update(self):
        pass

    @abstractproperty
    def status(self):
        raise NotImplementedError

    @abstractproperty
    def status_message(self):
        raise NotImplementedError

    # -------------- Post retrieval methods --------------------------------------

    def post(self, path, revision=None):
        if path is None:
            raise ValueError("path is None")
        path = self._kp_path(path)
        if not self.has_post(path, revision=revision) and path in self.config.aliases:
            path = self.config.aliases[path]
            if path in self.config.alias:
                raise ValueError("Alias cycle detected.")
        assert self.has_post(
            path, revision=revision
        ), "{} does not have a post for path '{}'.".format(
            self.__class__.__name__, path
        )
        return KnowledgePost(
            path=path, repository=self, revision=revision or self._kp_get_revision(path)
        )

    def dir(self, prefix=None, status=None):
        if prefix is None or isinstance(prefix, str):
            prefixes = [prefix]
        else:
            prefixes = prefix
        assert all(
            [prefix is None or isinstance(prefix, str) for prefix in prefixes]
        ), "All path prefixes must be strings."
        prefixes = [
            prefix if prefix is None else posixpath.relpath(prefix)
            for prefix in prefixes
        ]
        if isinstance(status, str):
            if status == "all":
                status = [
                    self.PostStatus.DRAFT,
                    self.PostStatus.SUBMITTED,
                    self.PostStatus.PUBLISHED,
                    self.PostStatus.UNPUBLISHED,
                ]
            else:
                raise ValueError("Status alias `{}` not recognised.".format(status))
        if status is not None and not isinstance(status, list):
            status = [status]
        elif status is None:
            status = [self.PostStatus.PUBLISHED]

        # Use old syntax for "yielding from" to maintain support for python 2
        for prefix in prefixes:
            for path in self._dir(prefix=prefix, statuses=status):
                yield path

    @abstractmethod
    def _dir(self, prefix, statuses):
        raise NotImplementedError

    def has_post(self, path, revision=None):
        return self._kp_exists(self._kp_path(path), revision=revision)

    def post_status(self, path, revision=None, detailed=False):
        return self._kp_status(
            self._kp_path(path), revision=revision, detailed=detailed
        )

    def post_statuses(self, paths, detailed=False):
        return OrderedDict(
            [(path, self.post_status(path, detailed=detailed)) for path in paths]
        )

    def posts(self, status=None, only_valid=False):
        for path in self.dir(status=status):
            post = self.post(path)
            if only_valid and not post.is_valid():
                continue
            yield post

    def __getitem__(self, path):
        return self.post(path)

    def __len__(self):
        return len(self.dir())

    def __iter__(self):
        return self.posts()

    def __contains__(self, path):
        return self.has_post(path)

    # -------------- Post submission / addition user flow --------------------

    def add(
        self, kp, path=None, update=False, **kwargs
    ):  # Create a new knowledge post draft
        assert isinstance(
            kp, KnowledgePost
        ), "One can only add KnowledgePost objects to a KnowledgeRepository."
        path = path or kp.path
        if not path:
            raise ValueError(
                "Post path not provided for Knowledge Post, and one is not specified within the knowledge post."
            )
        path = self._kp_path(path)
        path = self.config.path_parse(path)

        current_datetime = datetime.datetime.now()
        authors = kp.headers["authors"]
        new_authors = [self.config.username_parse(author) for author in authors]
        if new_authors != authors or kp.headers["updated_at"] < current_datetime:
            kp.update_headers(authors=new_authors, updated_at=current_datetime)

        for postprocessor, postprocessor_kwargs in self.config.postprocessors:
            KnowledgePostProcessor._get_subclass_for(postprocessor)(
                **postprocessor_kwargs
            ).process(kp)

        cleanup_kwargs = self._add_prepare(kp, path, update, **kwargs)

        self._kp_save(kp, path, update=update)

        if cleanup_kwargs:
            kwargs.update(cleanup_kwargs)
        self._add_cleanup(kp, path, update, **kwargs)

        return kp

    @abstractmethod
    def _add_prepare(self, kp, path, update=False):
        raise NotImplementedError

    @abstractmethod
    def _add_cleanup(self, kp, path, update=False):
        raise NotImplementedError

    def revise(self, kp, path, **kwargs):
        return self.add(kp, path, update=True, **kwargs)

    def submit(self, path):  # Submit a post for review
        return self._submit(self._kp_path(path))

    @abstractmethod
    def _submit(self, path):  # Submit a post for review
        raise NotImplementedError

    def accept(self, path):
        return self._accept(self._kp_path(path))

    @abstractmethod
    def _accept(self, path):
        raise NotImplementedError

    def publish(self, path):  # Publish a post for general perusal
        return self._publish(self._kp_path(path))

    @abstractmethod
    def _publish(self, path):  # Publish a post for general perusal
        raise NotImplementedError

    def unpublish(self, path):  # Unpublish a post for general perusal
        return self._unpublish(self._kp_path(path))

    @abstractmethod
    def _unpublish(self, path):  # Unpublish a post for general perusal
        raise NotImplementedError

    def remove(self, path):
        return self._remove(self._kp_path(path))

    @abstractmethod
    def _remove(self, path):
        raise NotImplementedError

    def remove_all(self):
        for path in self.dir():
            self._remove(path)

    # ----------- Knowledge Post Data Retrieval/Pushing Methods --------------------

    def _kp_repository_uri(self, path):
        return self.uri

    @abstractmethod
    def _kp_uuid(self, path):
        raise NotImplementedError

    def _kp_path(self, path, rel="/"):
        if path is None:
            return None
        path = os.path.relpath(os.path.abspath(os.path.join(rel, path)), rel)
        if os.name == "nt":
            path = path.replace(os.path.sep, os.path.altsep)
        assert all(
            [not segment.endswith(".kp") for segment in path.split("/")[:-1]]
        ), "The post path may not contain a directory named '*.kp'."
        if path == "." or path.startswith(".."):
            raise ValueError(
                "Provided path '{}' is outside of the knowledge repository.".format(
                    path
                )
            )
        if not path.endswith(".kp"):
            path += ".kp"
        return path

    @abstractmethod
    def _kp_exists(self, path, revision=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_status(self, path, revision=None, detailed=False):
        raise NotImplementedError

    @abstractmethod
    def _kp_get_revision(self, path, status=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_get_revisions(self, path):
        raise NotImplementedError

    @abstractmethod
    def _kp_read_ref(self, path, reference, revision=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_dir(self, path, parent=None, revision=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_has_ref(self, path, reference, revision=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_diff(self, path, head, base):
        raise NotImplementedError

    @abstractmethod
    def _kp_write_ref(self, path, reference, data, uuid=None, revision=None):
        raise NotImplementedError

    @abstractmethod
    def _kp_new_revision(self, path, uuid=None):
        raise NotImplementedError

    def _kp_web_uri(self, path):
        return self.config.web_uri(path)

    def _kp_save(self, kp, path, update=False):
        if not update and self.has_post(path):
            raise ValueError(
                "A knowledge post with the same path already exists. To update it, set the update flag."
            )
        kp.uuid = self._kp_uuid(path) or kp.uuid
        kp.path = path
        kp.revision = self._kp_new_revision(path, uuid=kp.uuid)
        kp.repository = self

        for ref in kp._dir():
            self._kp_write_ref(
                path, ref, kp._read_ref(ref), uuid=kp.uuid, revision=kp.revision
            )

    @property
    def web_uri(self):
        return self.config.web_uri()

    # ----------- Interface with web app ----------------------------------
    def get_app(self, *args, **kwargs):
        from brix import app

        return self.config.prepare_app(app.KnowledgeFlask(self, *args, **kwargs))
