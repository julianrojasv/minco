# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Okta authentication provider
"""
import os
import logging
import time
from typing import Optional
from urllib.parse import urlencode, urljoin

from flask import g, redirect, render_template, request, session, url_for, Response
from flask_oidc import OpenIDConnect
from oauth2client.client import OAuth2Credentials

from brix.app.proxies import db_session
from brix.app.utils.user import get_or_create
from ..auth_provider import KnowledgeAuthProvider


class TokenCache:
    """Helper to cache session tokens"""

    def __init__(self):
        self._cache = {}

    def clear_expired(self):
        """Clear expired tokens"""
        for token_id in list(self._cache):
            if time.time() > self._cache[token_id]:
                del self._cache[token_id]

    def add(self, token):
        """Add a new token to cache"""
        if not token:
            return
        # jti - a unique identifier for this ID token
        # https://developer.okta.com/docs/reference/api/oidc/#id-token
        self._cache[token["jti"]] = token["exp"]

    def remove(self, token):
        """Remove token"""
        if token and token["jti"] in self._cache:
            del self._cache[token["jti"]]

    def is_valid(self, token):
        """Check if token still valid"""
        return token and token["jti"] in self._cache


class BrixOpenIDConnect(OpenIDConnect):
    """
    Custom implementation of flask.oidc OpenID Connect Client to enable
    passing in client secrets as environment variables.
    """

    def __init__(self, app):
        self.token_cache = TokenCache()
        super().__init__(app=app,)

    def _before_request(self):
        super()._before_request()
        self.token_cache.clear_expired()

    def _set_cookie_id_token(self, id_token):
        super()._set_cookie_id_token(id_token)
        if id_token:
            self.token_cache.add(id_token)

    def logout(self):
        if g.oidc_id_token:
            self.token_cache.remove(g.oidc_id_token)
        super().logout()

    @property
    def user_loggedin(self):
        logged_in = super().user_loggedin and self.token_cache.is_valid(g.oidc_id_token)
        # if the server has been restarted (ie redeployed)
        # but the token is still valid (hasn't expired and still active)
        # we need to log out the user, otherwise the user will not be able
        # to login until the cookie expires
        if not logged_in:
            self.logout()
        return logged_in

    def load_secrets(self, app):
        try:
            base_uri = os.environ["RECIPES_OKTA_ORG_URL"]
            return {
                "web": {
                    "client_id": os.environ["RECIPES_CLIENT_ID"],
                    "client_secret": os.environ["RECIPES_CLIENT_SECRET"],
                    "auth_uri": "{}/oauth2/v1/authorize".format(base_uri),
                    "token_uri": "{}/oauth2/v1/token".format(base_uri),
                    "issuer": "{}/oauth2".format(base_uri),
                    "userinfo_uri": "{}/oauth2/userinfo".format(base_uri),
                    "redirect_uris": [
                        "{}/auth/login/okta/authorize".format(
                            os.environ["RECIPES_BASE_URL"]
                        )
                    ],
                }
            }
        except KeyError as exception:
            raise KeyError(
                "Missed {} environment variable for Okta auth provider".format(
                    exception
                )
            )


class OktaAuthProvider(KnowledgeAuthProvider):
    """
    Implementation of the brix provider for Okta authentication.
    """

    _registry_keys = ["okta"]

    def __init__(self, name, app, **kwargs):
        app.config["OIDC_CLIENT_SECRETS"] = ""
        app.config["OIDC_COOKIE_SECURE"] = (
            os.getenv("OIDC_COOKIE_SECURE", "").lower() != "false"
        )
        app.config["OIDC_CALLBACK_ROUTE"] = "/auth/login/okta/authorize"
        app.config["OIDC_SCOPES"] = ["openid", "email", "profile"]
        app.config["OVERWRITE_REDIRECT_URI"] = (
            "{}/auth/login/okta/authorize".format(os.environ["RECIPES_BASE_URL"])
            or False
        )
        self.oidc = BrixOpenIDConnect(app)
        super().__init__(name, app, **kwargs)

    def init(self, **kwargs):
        @self.app.before_request
        def before_request():  # pylint:disable=inconsistent-return-statements,unused-variable
            if self.oidc.user_loggedin:
                self.authorize()
            else:
                g.user = None
                if request.endpoint:
                    endpoints_to_skip = [
                        "static",
                        "auth_provider.okta",
                        "_oidc_callback",
                        "health",
                    ]
                    skip = any(
                        [endpoint in request.endpoint for endpoint in endpoints_to_skip]
                    )
                    if not skip:
                        session["requested_url"] = request.url
                        template = self.prompt()
                        if request.endpoint == "index.render_index":
                            return template
                        return template, 401

    def prepare_blueprint(self, blueprint):
        blueprint = super().prepare_blueprint(blueprint)

        @blueprint.route("/login", methods=["GET", "POST"])
        @self.oidc.require_login
        def login():  # pylint:disable=unused-variable
            return redirect(
                session.get("requested_url") or url_for("index.render_feed")
            )

        return blueprint

    def prompt(self):
        return render_template("login.html")

    def get_user(self):
        email = self.oidc.user_getfield("email").lower()
        name = self.oidc.user_getfield("name")
        user = get_or_create(db_session, email, name)
        return user

    # pylint: disable=inconsistent-return-statements
    def logout(self) -> Optional[Response]:
        if self.oidc.user_loggedin:
            user_id = self.oidc.user_getfield("sub")
            # Sign users out by ending their local session.
            # This signs the user out of your application,
            # but doesn't sign the user out of Okta.
            self.oidc.logout()
            g.user = None

            if not self.oidc.credentials_store:
                logging.warning(
                    "Unable to signout user: OIDC credentials_store is empty"
                )
                return

            # After performing local signout, navigate the user's
            # browser to the OIDC logout page.
            # This page clears the user's Okta session, and then
            # redirects back to the post_logout_redirect_uri if is provided.
            # https://developer.okta.com/docs/reference/api/oidc/#logout
            id_token = OAuth2Credentials.from_json(
                self.oidc.credentials_store[user_id]
            ).token_response["id_token"]
            base_url = os.environ["RECIPES_OKTA_ORG_URL"]
            params = urlencode(
                {
                    "id_token_hint": id_token,
                    "post_logout_redirect_uri": os.environ["RECIPES_BASE_URL"],
                }
            )
            url = urljoin(base_url, f"/oauth2/v1/logout?{params}")
            return redirect(url)
