""" JIRA client ready to work client"""
# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

import base64
import binascii
import os

from jira import JIRA


class BrixJira:
    """ Brix Jira client
    """

    client = None

    def __init__(self):
        """ Jira client object initialization with oauth authentication
        """
        # because AWS secret store escape special characters that present in .pem files
        # we store key as base64 on AWS
        try:
            key_cert = base64.b64decode(os.environ['JIRA_KEY_CERT'])
        except binascii.Error:
            key_cert = os.environ['JIRA_KEY_CERT']

        self.client = JIRA(
            server=os.environ['JIRA_URL'],
            oauth={
                'access_token': os.environ['JIRA_ACCESS_TOKEN'],
                'access_token_secret': os.environ['JIRA_ACCESS_TOKEN_SECRET'],
                'key_cert': key_cert,
                "consumer_key": os.environ['JIRA_CONSUMER_KEY']
            }
        )

    @staticmethod
    def get_environment_template(context: dict) -> str:
        """Create agreed Jira environment field from the given context"""
        return f"*Current environment* \n" \
               f"** User id: {context['user_identifier']} \n" \
               f"** FE_Version: Brix v{context['version']} \n" \
               f"** Location: {context['location']} \n" \
               f"** User-Agent: {context['user_agent']} \n" \
               f"** Screen Resolution: {context['screen_resolution']} \n"

    def create_issue(self, summary: str, description: str, environment_context: dict = None) -> "Issue":
        """
        Create Alchemy feedback with summary and description and
        predefined project and issuetype fields
        Args:
            summary: Jira issue summary
            description: Jira issue description
            environment_context: context to build environment template
        Returns:
            issue: jira.resources.Issue object

        """
        return self.client.create_issue(
            project="ECO",
            summary=summary,
            description=description,
            issuetype={"name": "Feedback"},
            # epic link field
            customfield_10009="ECO-225",
            environment=self.get_environment_template(environment_context) if environment_context else ""
        )
