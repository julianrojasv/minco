"""Utils for authentication and authorization"""

import datetime
import logging
import os
from pathlib import Path

from flask import request
from flask_login import AnonymousUserMixin
from flask_principal import UserNeed
from future.moves.urllib.parse import urljoin, urlparse

from brix import app
from brix.app.models import User

from .. import roles
from ..proxies import current_app, db_session


def prepare_user(user, session_start=True):
    """
    Function for updating and saving user instance after login
    Args:
        user (User): models.User instance
        session_start (bool): if session is already started

    Returns:
        user: User models.instance

    """
    cache_lifetime = current_app.config["AUTH_USER_ATTRIBUTE_CACHE_LIFETIME"] or 0
    if current_app.config["AUTH_USER_ATTRIBUTE_SETTER"] and (
        session_start
        or user.last_login_at is None
        or user.last_login_at
        < datetime.datetime.now() - datetime.timedelta(seconds=cache_lifetime)
    ):
        session_start = True
        user = current_app.config["AUTH_USER_ATTRIBUTE_SETTER"](user)

    if session_start or user.id is None:
        user.last_login_at = datetime.datetime.now()
        db_session.add(user)
        db_session.commit()

    return user


class AnonymousKnowledgeUser(AnonymousUserMixin):
    """ Emulation of models.User class for anonymous user
    """

    id = None  # pylint: disable=invalid-name
    identifier = None
    created_at = None
    posts = []

    @property
    def subscriptions(self):
        """
        Empty subscriptions
        Returns: empty list

        """
        return []

    @property
    def liked_posts(self):
        """
        Empty liked posts
        Returns: empty list

        """
        return []


def is_safe_url(target):
    """
    Check if url is safe
    Args:
        target (str): string with url

    Returns:
        bool: if url us safe

    """
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ("http", "https") and ref_url.netloc == test_url.netloc


def populate_identity_roles(identity, user=None):
    """
    Check users permissions and populates appropriate roles for user
    Args:
        identity (Identity): flask principal identity object
        user (User): models.User object

    Returns:
        identity: flask principal identity with added roles
    """
    identity.user = user

    if user is None or user.is_anonymous:
        if current_app.config["POLICY_ANONYMOUS_VIEW_INDEX"]:
            identity.provides.add(roles.index_view)
        if current_app.config["POLICY_ANONYMOUS_VIEW_POST"]:
            identity.provides.add(roles.post_view)
        if current_app.config["POLICY_ANONYMOUS_VIEW_STATS"]:
            identity.provides.add(roles.stats_view)
        if current_app.config["POLICY_ANONYMOUS_DOWNLOADS"]:
            identity.provides.add(roles.post_download)

    else:
        identity.provides.add(UserNeed(user.identifier))
        identity.provides.add(roles.index_view)
        identity.provides.add(roles.post_view)
        identity.provides.add(roles.post_edit)
        identity.provides.add(roles.post_comment)
        identity.provides.add(roles.post_download)
        identity.provides.add(roles.stats_view)

        if user.is_admin:
            identity.provides.add(roles.admin)

    return identity
