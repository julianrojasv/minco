"""Helpers for posts rendering"""
from typing import List, Union
from urllib.parse import quote

import markdown
from markdown.extensions import toc

import pygments
from flask import url_for, escape
from jinja2 import Template

from brix.app.utils.user import email_to_name
from brix.post import KnowledgePost

MARKDOWN_EXTENSIONS = [
    "extra",
    "abbr",
    "attr_list",
    "def_list",
    "fenced_code",
    "footnotes",
    "tables",
    "admonition",
    "codehilite",
    "meta",
    "sane_lists",
    "smarty",
    toc.TocExtension(baselevel=1),
    "wikilinks",
    "nl2br",
]


def render_post_tldr(post: Union[KnowledgePost, "Post"]) -> str:
    """
    convert post tldr section to string with Markdown.convert
    Args:
        post: instance of post model or KnowledgePost

    Returns:
        converted string
    """
    if isinstance(post, KnowledgePost):
        result = markdown.Markdown(extensions=MARKDOWN_EXTENSIONS).convert(
            post.headers.get("tldr").strip()
        )
    else:
        result = markdown.Markdown(extensions=MARKDOWN_EXTENSIONS).convert(
            post.tldr.strip()
        )
    return result


def render_post_header(post: Union[KnowledgePost, "Post"]) -> str:
    """
    Render post headers html
    Args:
        post: instance of post model or KnowledgePost

    Returns:
        html string
    """

    header_template = Template(
        u"""
    <div class='metadata'>
    <span class='title'>{{title}}</span>
    {% if subtitle %}<span class='subtitle'>{{subtitle}}</span>{% endif %}
    <span class='authors'>{{authors}}</span>
    <div class="keyline_separator"></div>
    <span class="dates"><span class="separate-right">Created on <span class="date">{{date_created}} </span></span>
    Last updated <span class="date">{{date_updated}}</span></span>
    <span class='tldr'>{{tldr}}</span>
    <span class='tags'></span>
    </div>
    """
    )

    def get_authors(
        user_ident: List[str], user_names: List[str], user_images: List[str] = None
    ) -> str:
        """
        Render post authors
        Args:
            user_ident: list of user identifiers
            user_names: list of user names
            user_images: optional list of user avatar links

        Returns:
            html string
        """
        default_image = url_for("static", filename="images/profile_photo_default.png")
        if not user_images:
            user_images = [default_image] * len(user_names)
        authors = [
            "<a href='/author/{}'><img data-toggle='tooltip' data-placement='top' "
            "title='{}' class='post-avatar' src='{}'></a>".format(
                quote(user_ident),
                username,
                escape(user_image if user_image else default_image),
            )
            for user_ident, username, user_image in zip(
                user_ident, user_names, user_images
            )
        ]
        return "".join(authors)

    if isinstance(post, KnowledgePost):
        context = dict(
            title=post.headers["title"],
            subtitle=post.headers.get("subtitle"),
            authors=get_authors(
                post.headers["authors"],
                [email_to_name(author) for author in post.headers["authors"]],
            ),
            date_created=post.headers["created_at"].strftime("%B %d, %Y"),
            date_updated=post.headers["updated_at"].strftime("%B %d, %Y"),
            tldr=render_post_tldr(post),
        )
    else:
        context = dict(
            title=post.title,
            subtitle=post.subtitle,
            authors=get_authors(
                [author.identifier for author in post.authors],
                [author.format_name for author in post.authors],
                [author.avatar_uri for author in post.authors],
            ),
            date_created=post.created_at.strftime("%B %d, %Y"),
            date_updated=post.updated_at.strftime("%B %d, %Y"),
            tldr=render_post_tldr(post),
        )
    return header_template.render(**context)


def render_post_raw(post: Union[KnowledgePost, "Post"]) -> Union[bytes, str]:
    """Render post without formatting"""
    if isinstance(post, KnowledgePost):
        raw_post = post.read().encode("ascii", "ignore")
    else:
        raw_post = post.text.encode("ascii", "ignore")

    raw_post = pygments.highlight(
        code=raw_post,
        lexer=pygments.lexers.get_lexer_by_name("md"),
        formatter=pygments.formatters.get_formatter_by_name("html"),
    )

    return raw_post


def render_post(post, with_toc=False):
    """
    Renders the markdown as html
    """
    from brix.converters.html import HTMLConverter

    def intra_knowledge_urlmapper(name, url):
        if name == "a" and url.startswith("knowledge:"):
            return url_for("posts.render", path=url.split("knowledge:")[1]).replace(
                "%2F", "/"
            )  # Temporary fix before url revamp
        return None

    md, html = HTMLConverter(  # pylint:disable=protected-access
        post if isinstance(post, KnowledgePost) else post.kp
    )._render_markdown(skip_headers=True, urlmappers=[intra_knowledge_urlmapper])

    html = render_post_header(post) + html

    if with_toc:
        return {
            "html": html,
            "toc": md.toc if md is not None else None,
        }  # pylint:disable=no-member
    return html


def render_comment(comment) -> str:
    """Render comment with markdown"""
    return markdown.Markdown().convert(comment.text)
