# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
import logging
import os
import re
from pathlib import Path
from brix import app

from flask import escape

USER_PICTURES_PATH = str(Path(app.__file__).parent) + "/static/images/profile_pictures"
AVATARS_URI = "/static/images/profile_pictures/"


logger = logging.getLogger(__name__)


def email_to_name(email):
    return re.sub(r"\W+", " ", email.split("@")[0]).strip().title()


def get_or_create(session, email, name=None):
    from brix.app.models import User

    user = session.query(User).filter(User.identifier == email).first()
    if user:
        if name:
            user.name = name
    else:
        logger.info("+ New user " + email)
        user = User(identifier=email)
        user.email = email
        name = name or email_to_name(email)
        user.name = name
        user.preferred_name = name
        user.username = name
        update_avatar_uri(user)
        session.add(user)
        session.flush()
        session.commit()

    return user


def update_avatar_uri(user):
    try:
        if user.avatar_uri is None or user.identifier not in user.avatar_uri.lower():
            pictures = os.listdir(os.path.abspath(USER_PICTURES_PATH))
            pictures = {
                picture.rsplit(".", 1)[0].lower(): picture for picture in pictures
            }
            if user.identifier in pictures:
                user.avatar_uri = escape(
                    "{}{}".format(AVATARS_URI, pictures[user.identifier])
                )
                return user
    except Exception as exc:
        logger.error(exc)
    return None
