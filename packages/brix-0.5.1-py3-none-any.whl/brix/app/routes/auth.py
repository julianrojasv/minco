# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Authentication routes
"""
from flask import redirect, render_template, Blueprint, url_for
from flask_login import logout_user, login_required
from flask_principal import identity_changed, AnonymousIdentity

from ..proxies import current_app


blueprint = Blueprint(
    "auth", __name__, template_folder="../templates", static_folder="../static"
)


@blueprint.route("/auth/login", methods=["GET", "POST"])
def login():
    """Login"""
    providers = current_app.auth_providers

    if len(providers) == 1:
        return redirect(url_for("auth_provider.{}.prompt".format(providers[0].name)))

    return (
        render_template(
            "auth-switcher.html",
            providers=[
                {
                    "name": provider.name,
                    "icon_uri": provider.icon_uri,
                    "link_text": provider.link_text,
                }
                for provider in providers
            ],
        ),
        401,
    )


@blueprint.route("/auth/logout")
@login_required
def logout():
    """Logout from the app and from Okta"""
    providers = current_app.auth_providers

    # Okta is the only auth provider
    redirect_obj = None
    for provider in providers:
        redirect_obj = provider.logout()

    # call after provider.logout() as providers need
    # access to globally stored objects that logout_user clears
    logout_user()

    # Notify flask principal that the user has logged out
    # pylint: disable=protected-access
    identity_changed.send(
        current_app._get_current_object(), identity=AnonymousIdentity()
    )

    # redirect_obj needs to be called in order to trigger the logout
    if redirect_obj:
        return redirect_obj

    return redirect(url_for("index.render_feed"))
