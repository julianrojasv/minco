import os

from brix.app.deploy import KnowledgeDeployer, get_app_builder
from brix.cli.collect import load_config

# Copy of the https://github.com/quantumblack/QB_knowledge_repo/ docker/deploy.py command that is used for app deploy


def deploy():
    """
    Deploy the knowledge repo.
    """
    config: dict = load_config(".")
    deployment_config: dict = config["deployment"]

    if deployment_config["engine"] is not "gunicorn":
        raise ValueError("Only gunicorn is supported")

    if os.environ.get("RECIPES_POSTGRES_USER"):
        connection_string = "postgresql+psycopg2://{user}:{password}@{url}:5432/{db}".format(
            user=os.environ.get("RECIPES_POSTGRES_USER"),
            password=os.environ.get("RECIPES_POSTGRES_PASSWORD"),
            url=os.environ.get("RECIPES_POSTGRES_URL"),
            db=os.environ.get("RECIPES_POSTGRES_DB", ""),
        )
    else:
        connection_string = None

    app_builder = get_app_builder(
        os.path.join(os.getcwd(), ".repo"),
        debug=False,
        db_uri=connection_string
        or os.environ.get("RECIPES_POSTGRES")
        or deployment_config["dburi"],
        config=None,
        # because flask app config doesn't work with dicts as config - lets pass it as kwargs
        **config["flask_config"]
    )

    server = KnowledgeDeployer.using(deployment_config["engine"])(
        app_builder,
        host=deployment_config["host"],
        port=deployment_config["port"],
        workers=deployment_config["workers"],
        timeout=deployment_config["timeout"],
    )
    server.run()


if __name__ == "__main__":
    deploy()
