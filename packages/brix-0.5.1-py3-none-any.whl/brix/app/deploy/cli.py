import click

from brix import __version__
from brix.app.deploy import get_app_builder
from brix.cli.cli import repo_option
from brix.cli.collect import load_config


def get_app(repo, **kwargs):
    config = load_config(repo)
    repo_uri = config["repo_uri"]  # type:str
    return get_app_builder(repo_uri, config=config, **kwargs)()


@click.group(name="Brix flask app CLI",)
@click.version_option(__version__, "--version", "-V", help="Show version and exit")
def cli():
    """
    Admin brix flask app cli for deploying and managing the DB.
    """


@cli.command()
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str)
def reindex(repo, dburi):
    """
    Command for force reindex of the app. Separated from the main to avoid issues for db issues during serving with
    Gunicorn.
    """
    get_app(
        repo,
        db_uri=dburi,
        debug=False,
        INDEXING_ENABLED=True,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=True,
    ).db_update_index(reindex=True, check_timeouts=False, force=True)
    click.secho("Reindexing finished")


@cli.command()
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str)
def db_upgrade(repo, dburi):
    """
    Command for manual database upgrade.
    """
    get_app(
        repo,
        db_uri=dburi,
        debug=True,
        INDEXING_ENABLED=False,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=False,
    ).db_upgrade()


@cli.command()
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str)
@click.option("--message", help="Message for migration.", type=str)
def db_migrate(repo, dburi, message):
    """
    Create db migrations.
    """
    get_app(
        repo,
        db_uri=dburi,
        debug=True,
        INDEXING_ENABLED=False,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=False,
    ).db_migrate(message)


@cli.command()
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str, required=True)
@click.option(
    "--report-folder",
    help="Folder with coverage.",
    type=click.Path(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True, writable=False
    ),
    prompt=False,
    required=True,
)
def update_post_coverage(repo, dburi, report_folder):
    """
    Update coverage column for all posts from the xml reports that contains at report_folder.
    """
    get_app(
        repo,
        db_uri=dburi,
        debug=True,
        INDEXING_ENABLED=False,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=False,
    ).update_post_coverage(report_folder)


def main():  # pragma: no cover
    """
    Main entry point
    """
    cli()


if __name__ == "__main__":  # pragma: no cover
    main()
