"""
Admin pages based on Flask-Admin
"""

from flask import abort
from flask_admin import Admin, expose, AdminIndexView
from flask_admin.contrib.sqla import ModelView

from brix.app import permissions
from brix.app.models import Post
from brix.app.models import User
from brix.app.models import Group
from brix.app.models import DownloadReason
from brix.app.models import Email
from brix.app.models import Comment
from brix.app.models import ErrorLog
from brix.app.models import PageView
from brix.app.models import Vote
from brix.app.models import Tag
from brix.app.models import Subscription
from brix.app.models import Topic
from brix.app.proxies import db_session


class AdminPermissionMixin:
    """
        Mixin for Flask-Admin view to set global permissions to admin role
    """

    def is_accessible(self) -> bool:  # pylint: disable=no-self-use
        """
        Check if user has admin permissions
        Returns:
           True if the user has admin permissions

        """
        return permissions.admin.can()


class AdminModelView(AdminPermissionMixin, ModelView):
    """
        Create custom blueprint names to avoid name conflicts with existing
    """

    def create_blueprint(self, admin: Admin) -> "Blueprint":
        """
        create blueprint with admin prefix to exclude name collisions with regular blueprints
        Args:
            admin:

        Returns:
            blueprint
        """
        blueprint = super().create_blueprint(admin)
        blueprint.name = "{}_admin".format(blueprint.name)
        return blueprint

    def get_url(self, endpoint, **kwargs):
        if not (endpoint.startswith(".") or endpoint.startswith("admin.")):
            endpoint = endpoint.replace(".", "_admin.")
        return super().get_url(endpoint, **kwargs)


class UserAdmin(AdminModelView):  # pylint: disable=too-many-ancestors
    """
    Custom admin class for User model
    """

    column_exclude_list = ("password",)
    column_hide_backrefs = False
    column_searchable_list = ["name", "email"]


class DownloadReasonAdmin(AdminModelView):  # pylint: disable=too-many-ancestors
    """Admin page for DownloadReason model"""

    column_hide_backrefs = False
    column_list = ("created_at", "user", "reason", "notes", "post")
    column_default_sort = ("created_at", True)


class HomeView(AdminIndexView):
    """
        Custom index view to not admin users to return 404 instead of 403
    """

    @expose("/")
    def index(self):
        if not permissions.admin.can():
            return abort(404)
        return super().index()


def init_admin(app: "KnowledgeFlask"):
    """
        Function for admin initialization. All new views should be added to admin.add_views method
    Args:
        app: KnowledgeFlask app instance

    Returns:

    """

    with app.app_context():
        admin = Admin(
            app,
            index_view=HomeView(url="/admin"),
            name="brix admin",
            template_mode="bootstrap3",
            url="/admin",
        )
        admin.add_views(
            UserAdmin(User, db_session),
            AdminModelView(Group, db_session),
            AdminModelView(Post, db_session),
            AdminModelView(Topic, db_session),
            AdminModelView(Subscription, db_session),
            AdminModelView(Tag, db_session),
            AdminModelView(Vote, db_session),
            AdminModelView(PageView, db_session),
            AdminModelView(ErrorLog, db_session),
            AdminModelView(Comment, db_session),
            AdminModelView(Email, db_session),
            DownloadReasonAdmin(DownloadReason, db_session),
        )
