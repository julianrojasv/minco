"""Flask application object"""

from __future__ import absolute_import

import imp
import logging
import math
import mimetypes
import os
import traceback
import uuid
from datetime import datetime
from typing import Tuple

import six
from alembic import command
from alembic.runtime.migration import MigrationContext
from flask import Flask, current_app, render_template, request, session
from flask_login import LoginManager, user_loaded_from_request
from flask_mail import Mail
from flask_migrate import Migrate
from flask_principal import (
    AnonymousIdentity,
    Identity,
    PermissionDenied,
    Principal,
    identity_loaded,
)
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from werkzeug.urls import url_encode

from brix.app.admin import init_admin
from brix.app.forms import FeedbackForm
from brix.app.utils.posts import update_post_coverage
from brix.repo import KnowledgeRepository

from . import routes
from .auth_provider import KnowledgeAuthProvider
from .index import (
    set_up_indexing_timers,
    time_since_index,
    time_since_index_check,
    update_index,
)
from .models import Tag, User
from .models import db as sqlalchemy_db
from .proxies import current_repo, current_user, db_session
from .utils.auth import AnonymousKnowledgeUser, populate_identity_roles, prepare_user

# Needed to serve svg with correct mime type over https
mimetypes.add_type("image/svg+xml", ".svg")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class KnowledgeFlask(Flask):
    """brix flask application"""

    def __init__(
        self,
        repo: str,
        db_uri: str = None,
        debug: bool = None,
        config: object = None,
        **kwargs
    ):  # pylint:disable=too-many-locals,too-many-branches,too-many-statements
        """
        Initialization of flask app
        Args:
            repo: Path to the brix repository
            db_uri: DB connection string
            debug: Indicates if app in debug mode
            config: Config object
            **kwargs: Additional parameters for config
        """
        Flask.__init__(
            self, __name__, template_folder="templates", static_folder="static"
        )

        # Add unique identifier for this application isinstance
        self.uuid = str(uuid.uuid4())
        if "KNOWLEDGE_REPO_MASTER_UUID" not in os.environ:
            logger.info("Set KNOWLEDGE_REPO_MASTER_UUID to '%s'.", self.uuid)
            os.environ["KNOWLEDGE_REPO_MASTER_UUID"] = self.uuid

        # Preload default configuration
        self.config.from_object("brix.app.config_defaults")

        # Load configuration from file or provided object
        if config:
            if isinstance(config, six.string_types):
                config = imp.load_source(
                    "knowledge_server_config", os.path.abspath(config)
                )
            if isinstance(config, dict):
                self.config.update(config.get("flask_config", {}))
            self.config.from_object(config)

        # Add configuration passed in as keyword arguments
        self.config.update(kwargs)

        # Prepare repository, and add it to the app
        if hasattr(config, "prepare_repo"):
            repo = config.prepare_repo(repo)
        self.repository = repo
        assert isinstance(
            self.repository, KnowledgeRepository
        ), "Invalid repository object provided."

        # Set debug mode from kwargs or else maintain current setting
        if debug is not None:
            self.config["DEBUG"] = debug

        # Set the secret key for this instance (creating one if one does not exist already)
        self.config["SECRET_KEY"] = self.config["SECRET_KEY"] or str(uuid.uuid4())

        # Configure database
        if db_uri:
            self.config["SQLALCHEMY_DATABASE_URI"] = db_uri
        logger.debug(u"Using database: %s", self.config["SQLALCHEMY_DATABASE_URI"])

        # Register database schema with flask app
        sqlalchemy_db.init_app(self)

        # Set up database migration information
        # Registers Migrate plugin in self.extensions['migrate']
        Migrate(self, self.db)

        # Try to create the database if it does not already exist
        # Existence is determined by whether there is an existing alembic migration revision
        db_auto_create = self.config.get("DB_AUTO_CREATE", True)
        db_auto_upgrade = self.config.get("DB_AUTO_UPGRADE", True)
        if db_auto_create and self.db_revision is None:
            self.db_init()
        elif db_auto_upgrade:
            self.db_upgrade()

        # Ensure that indexes are set up if required by the time first page is
        # served.
        @self.before_first_request
        def _start_indexing():
            if self.config["INDEXING_ENABLED"]:
                self.start_indexing()

        # Initialise login manager to keep track of user sessions
        self.login_manager = LoginManager()
        self.login_manager.init_app(self)
        self.login_manager.login_view = "auth.login"
        self.login_manager.anonymous_user = AnonymousKnowledgeUser

        @self.login_manager.user_loader
        def _load_user(user_id):
            return User(identifier=user_id)

        # Attempt login via http headers
        if self.config.get("AUTH_USE_REQUEST_HEADERS"):

            @self.login_manager.request_loader
            def _load_user_from_request(  # pylint:disable=inconsistent-return-statements
                request_,
            ):
                user_attributes = current_app.config.get("AUTH_MAP_REQUEST_HEADERS")(
                    request_.headers
                )
                if isinstance(user_attributes, dict) and user_attributes.get(
                    "identifier", None
                ):
                    user = User(identifier=user_attributes["identifier"])
                    user.can_logout = False
                    for attribute in ["avatar_uri", "email", "name"]:
                        if user_attributes.get(attribute):
                            setattr(user, attribute, user_attributes[attribute])
                    user = prepare_user(user, session_start=False)
                    return user

        elif self.config.get("AUTH_USER_IDENTIFIER_REQUEST_HEADER"):
            logger.warning(
                "AUTH_USER_IDENTIFIER* configuration keys are deprecated and will be removed in v0.9.0 ."
            )

            @self.login_manager.request_loader
            def _load_user_from_request(  # pylint:disable=inconsistent-return-statements
                request_,
            ):
                identifier = request_.headers.get(
                    current_app.config["AUTH_USER_IDENTIFIER_REQUEST_HEADER"]
                )
                if identifier:
                    if current_app.config[
                        "AUTH_USER_IDENTIFIER_REQUEST_HEADER_MAPPING"
                    ]:
                        identifier = current_app.config[
                            "AUTH_USER_IDENTIFIER_REQUEST_HEADER_MAPPING"
                        ](identifier)
                    user = User(identifier=identifier)
                    user.can_logout = False
                    user = prepare_user(user, session_start=False)
                    return user

        # Intialise access policies
        self.principal = Principal(self)

        # Add AnonymousIdentity fallback so that on_identity_loaded is called for
        # anonymous users too.
        self.principal.identity_loaders.append(
            lambda: AnonymousIdentity()  # pylint:disable=unnecessary-lambda
        )

        # Synchronise user permissions with data model
        @user_loaded_from_request.connect
        def _on_user_loaded_from_request(_sender, user):
            self.principal.set_identity(Identity(user.id))

        @identity_loaded.connect_via(self)
        def _on_identity_loaded(_sender, identity):
            populate_identity_roles(identity, user=current_user)

        @self.errorhandler(PermissionDenied)
        def _handle_insufficient_permissions(_error):
            session["requested_url"] = request.url
            return render_template("permission_denied.html"), 403

        init_admin(self)

        # Add mail object if configuration is supplied
        if self.config.get("MAIL_SERVER"):
            self.config["mail"] = Mail(self)

        # Register routes to be served
        self.register_blueprint(routes.posts.blueprint)
        self.register_blueprint(routes.health.blueprint)
        self.register_blueprint(routes.index.blueprint)
        self.register_blueprint(routes.tags.blueprint)
        self.register_blueprint(routes.vote.blueprint)
        self.register_blueprint(routes.comment.blueprint)
        self.register_blueprint(routes.stats.blueprint)
        self.register_blueprint(routes.editor.blueprint)

        CSRFProtect(self)
        # don't need groups for users
        # self.register_blueprint(routes.groups.blueprint)
        self.register_blueprint(routes.auth.blueprint)
        KnowledgeAuthProvider.register_auth_provider_blueprints(self)

        if self.config["DEBUG"]:
            self.register_blueprint(routes.debug.blueprint)

        # Register error handler
        @self.errorhandler(500)
        def _show_traceback(_self):
            """ If LOCAL MODE: show the stack trace on a server error
                otherwise show a nice error template to the users
            """
            error_template = render_template("error.html")
            if current_app.config.get("DEBUG"):
                error_template = (
                    render_template("traceback.html", info=traceback.format_exc()),
                    500,
                )
            return error_template

        @self.errorhandler(404)
        def _show_404(_self):
            return render_template("404.html")

        @self.before_first_request
        def _ensure_excluded_tags_exist():
            # For every tag in the excluded tags, create the tag object if it doesn't exist
            excluded_tags = current_app.config["EXCLUDED_TAGS"]
            for tag in excluded_tags:
                Tag(name=tag)
            db_session.commit()

        @self.before_request
        def _open_repository_session():
            if not request.path.startswith("/static"):
                current_repo.session_begin()

        @self.after_request
        def _close_repository_session(response):
            if not request.path.startswith("/static"):
                current_repo.session_end()
            return response

        @self.after_request
        def _update_response_headers(response):
            # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options
            response.headers["X-Frame-Options"] = "DENY"
            # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-XSS-Protection
            response.headers["X-XSS-Protection"] = 1
            # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options
            response.headers["X-Content-Type-Options"] = "nosniff"
            # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy
            # this policy is NOT secure at all
            response.headers[
                "Content-Security-Policy"
            ] = "default-src * data: 'unsafe-inline' 'unsafe-eval'"
            # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Strict-Transport-Security
            response.headers[
                "Strict-Transport-Security"
            ] = "max-age=63072000; includeSubDomains; preload"
            return response

        @self.context_processor
        def _webediting_enabled():
            # TODO: Link this more to KnowledgeRepository capability and
            # configuration rather than a specific name.
            return {"webeditor_enabled": "webposts" in current_repo.uris}

        @self.context_processor
        def _inject_last_index():
            return dict(
                last_index=time_since_index(human_readable=True),
                last_index_check=time_since_index_check(human_readable=True),
            )

        @self.context_processor
        def feedback_form():  # pylint:disable=unused-variable
            form = FeedbackForm()
            return {"feedback_form": form}

        @self.template_global()
        def modify_query(**new_values):  # pylint:disable=unused-variable
            args = request.args.copy()

            for key, value in new_values.items():
                args[key] = value

            return u"{}?{}".format(request.path, url_encode(args))

        @self.template_global()
        def pagination_pages(
            current_page, page_count, max_pages=5, extremes=True
        ):  # pylint:disable=unused-variable
            page_min = int(max(1, current_page - math.floor(1.0 * max_pages // 2)))
            page_max = int(
                min(page_count, current_page + math.floor(1.0 * max_pages / 2))
            )

            to_acquire = max_pages - (page_max - page_min + 1)

            while to_acquire > 0 and page_min > 1:
                page_min -= 1
                to_acquire -= 1
            while to_acquire > 0 and page_max < page_count:
                page_max += 1
                to_acquire -= 1

            pages = list(range(page_min, page_max + 1))
            if extremes:
                if 1 not in pages:
                    pages[0] = 1
                if page_count not in pages:
                    pages[-1] = page_count
            return pages

        @self.template_filter("format_date")
        def _format_date(date: datetime) -> str:
            """
            This will be a Jinja filter that string formats a datetime object.
            If we can't correctly format, we just return the object.
            Args:
                date: Datetime object

            Returns:
                A string of the format of YYYY-MM-DD

            """
            try:
                return datetime.strftime(date, "%Y-%m-%d")
            except (TypeError, ValueError):
                return date

        @self.template_filter("pluralize")
        def _pluralize(number: int, singular: str = "", plural: str = "s") -> str:
            """Template filter for string pluralization"""
            ret = singular
            if number != 1:
                ret = plural
            return ret

    @property
    def repository(self) -> KnowledgeRepository:
        """
        Returns:
            App repository object
        """
        return getattr(self, "_repository")

    @repository.setter
    def repository(self, repo: KnowledgeRepository):
        """
        Args:
            repo: Repository object
        """
        self._repository = repo

    @property
    def db(self) -> SQLAlchemy:
        """
        Returns:
            SqlAlchemy: database object
        """
        return sqlalchemy_db

    @property
    def _alembic_config(self) -> "alembic.Config":
        """
        Raises:
            RuntimeError: when app doesn't have flask migration extension
        Returns:
             Alembic config object(alembic.ini from migrations path)
        """
        if not hasattr(self, "extensions") or "migrate" not in self.extensions:
            raise RuntimeError(
                "KnowledgeApp has not yet been configured. Please instantiate it via `get_app_for_repo`."
            )
        migrations_path = os.path.join(os.path.dirname(__file__), "migrations")
        return self.extensions["migrate"].migrate.get_config(migrations_path)

    def db_init(self) -> "KnowledgeFlask":
        """
        Initialize application sqlalchemy db and set migration head
        Returns:
             App instance
        """
        with self.app_context():
            # Create all tables
            sqlalchemy_db.create_all()

            # Stamp table as being current
            command.stamp(self._alembic_config, "head")
        return self

    @property
    def db_revision(self) -> Tuple:
        """
        Get current app migration revision
        Returns:
            Alembic migration revision

        """
        with self.app_context():
            conn = self.db.engine.connect()

            context = MigrationContext.configure(conn)
            return context.get_current_revision()

    def db_upgrade(self) -> "KnowledgeFlask":
        """
        Upgrade db to the head migration
        Returns:
            App instance
        """
        with self.app_context():
            command.upgrade(self._alembic_config, "head")
        return self

    def db_downgrade(self, revision: str) -> "KnowledgeFlask":
        """
        Downgrade db to the given revision
        Args:
            revision: name of revision

        Returns:
            App instance

        """
        with self.app_context():
            command.downgrade(self._alembic_config, revision)
        return self

    def db_migrate(self, message: str, autogenerate: bool = True) -> "KnowledgeFlask":
        """
        Create new alembic migration
        Args:
            message: Name of the migration(will be the part of the file name)
            autogenerate: Should it be manual or autogenerated

        Returns:
            App instance

        """
        with self.app_context():
            command.revision(
                self._alembic_config, message=message, autogenerate=autogenerate
            )
        return self

    def db_update_index(
        self, check_timeouts: bool = True, force: bool = False, reindex: bool = False
    ) -> "KnowledgeFlask":
        """
        Update database with posts from the repository
        Args:
            check_timeouts: Indicates if function will check for timeouts between reindex
            force: If force run
            reindex: If we should reindex existing metadata

        Returns:
            App instance

        """
        with self.app_context():
            update_index(check_timeouts=check_timeouts, force=force, reindex=reindex)
        return self

    def start_indexing(self) -> "KnowledgeFlask":
        """
        Start indexing of app repo
        Returns:
            App instance

        """
        if not getattr(self, "_indexing_started", False):
            set_up_indexing_timers(self)
            self._indexing_started = True
        return self

    def check_thread_support(
        self, check_index: bool = True, check_repositories: bool = True
    ) -> bool:
        """
        If index database is an sqlite database, it will lock on any write action, and so breaks on multiple threads
        Repository uris will break as above (but less often since they are not often written too), but will also
        end up being a separate repository per thread; breaking consistency of presented content.
        Args:
            check_index: Check app db
            check_repositories: Check repositories db

        Returns:
             True if app support threading else False

        """
        ret = True
        if check_index:
            index_db = self.config["SQLALCHEMY_DATABASE_URI"]
            if index_db.startswith("sqlite://"):
                ret = False

        if check_repositories:
            for uri in self.repository.uris.values():
                if uri.startswith("sqlite://") or ":memory:" in uri:
                    ret = False

        return ret

    def update_post_coverage(self, report_folder: str):
        """
        Update posts coverage from the pytest xml reports
        Args:
            report_folder: path with pytest xml reports

        Returns:

        """
        with self.app_context():
            update_post_coverage(report_folder)
