"""Initial version

Revision ID: 000000000000
Revises: None
Create Date: 2016-08-18 17:04:32.542965

"""

# revision identifiers, used by Alembic.
revision = "000000000000"
down_revision = None

from alembic import op
import sqlalchemy as sa
from sqlalchemy import orm
from brix.app.models import Group, User


ADMINS = ["nikolaos.tsaousis@quantumblack.com", "wesley.leong@quantumblack.com"]


def upgrade():
    op.create_table(
        "comments",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("post_id", sa.Integer(), nullable=True),
        sa.Column("text", sa.Text(), nullable=True),
        sa.Column("type", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "emails",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("trigger_id", sa.Integer(), nullable=True),
        sa.Column("trigger_type", sa.String(length=100), nullable=True),
        sa.Column("object_id", sa.Integer(), nullable=True),
        sa.Column("object_type", sa.String(length=100), nullable=True),
        sa.Column("sent_at", sa.DateTime(), nullable=True),
        sa.Column("subject", sa.Text(), nullable=True),
        sa.Column("text", sa.Text(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "pageviews",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("page", sa.String(length=512), nullable=True),
        sa.Column("endpoint", sa.String(length=255), nullable=True),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("object_id", sa.Integer(), nullable=True),
        sa.Column("object_type", sa.String(length=100), nullable=True),
        sa.Column("ip_address", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("object_action", sa.String(length=100), nullable=True),
        sa.Column("version", sa.String(length=100), nullable=True),
        sa.Column("id_errorlog", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "posts",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("uuid", sa.String(length=100), nullable=True),
        sa.Column("path", sa.String(length=512), nullable=True),
        sa.Column("project", sa.String(length=512), nullable=True),
        sa.Column("repository", sa.String(length=512), nullable=True),
        sa.Column("revision", sa.Integer(), nullable=True),
        sa.Column("title", sa.Text(), nullable=True),
        sa.Column("subtitle", sa.Text(), nullable=True),
        sa.Column("tldr", sa.Text(), nullable=True),
        sa.Column("keywords", sa.Text(), nullable=True),
        sa.Column("thumbnail", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.Column("status", sa.Integer(), nullable=True),
        sa.Column("private", sa.Integer(), nullable=True),
        sa.Column("coverage", sa.Float(), server_default=sa.text("0"), nullable=False),
        sa.Column("topic_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("path"),
        sa.UniqueConstraint("uuid"),
    )
    op.create_table(
        "subscriptions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("object_id", sa.Integer(), nullable=True),
        sa.Column("object_type", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "tags",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=500), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("identifier", sa.String(length=500), nullable=False, unique=True),
        sa.Column("username", sa.String(length=500), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("password", sa.String(length=500), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=True),
        sa.Column("name", sa.String(length=500), nullable=True),
        sa.Column("preferred_name", sa.String(length=500), nullable=True),
        sa.Column("avatar_uri", sa.VARCHAR(length=500), nullable=True),
        sa.Column("email", sa.String(length=500), nullable=True),
        sa.Column("last_login_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "votes",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("object_id", sa.Integer(), nullable=True),
        sa.Column("object_type", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "assoc_post_author",
        sa.Column("post_id", sa.Integer(), nullable=True),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("order", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["post_id"], ["posts.id"],),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"],),
    )
    op.create_table(
        "assoc_post_tag",
        sa.Column("post_id", sa.Integer(), nullable=True),
        sa.Column("tag_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["post_id"], ["posts.id"],),
        sa.ForeignKeyConstraint(["tag_id"], ["tags.id"],),
    )
    op.create_table(
        "groups",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=True, unique=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "assoc_group_user",
        sa.Column("group_id", sa.Integer(), nullable=True),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["group_id"], ["groups.id"],),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"],),
    )
    op.create_table(
        "assoc_post_group",
        sa.Column("post_id", sa.Integer(), nullable=True),
        sa.Column("group_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["group_id"], ["groups.id"],),
        sa.ForeignKeyConstraint(["post_id"], ["posts.id"],),
    )

    op.create_table(
        "index_metadata",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("type", sa.String(length=255), nullable=False),
        sa.Column("name", sa.String(length=512), nullable=False),
        sa.Column("value", sa.String(length=512), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("type", "name", name="_uc_type_name"),
    )

    op.create_table(
        "errorlog",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("function", sa.String(length=100), nullable=True),
        sa.Column("location", sa.String(length=255), nullable=True),
        sa.Column("message", sa.Text(), nullable=True),
        sa.Column("traceback", sa.Text(), nullable=True),
        sa.Column("version", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "download_reasons",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column(
            "reason",
            sa.Enum("project", "research", "learning", "other", name="reasonenum"),
            nullable=False,
        ),
        sa.Column("notes", sa.String(length=512), nullable=True),
        sa.Column("download_id", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["download_id"], ["pageviews.id"],),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"],),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "topic",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=500), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )
    op.create_foreign_key(None, "posts", "topic", ["topic_id"], ["id"])

    _create_admins()


def _create_admins():
    # create Admin group and assign initial admins
    bind = op.get_bind()
    session = orm.Session(bind=bind)
    admin_group = Group(name="admin")

    admin_group = session.merge(admin_group)
    session.add(admin_group)

    users = session.query(User).filter(User.identifier.in_(ADMINS)).all()
    admin_group.users = users
    session.commit()


def downgrade():
    op.drop_table("assoc_post_tag")
    op.drop_table("assoc_post_author")
    op.drop_table("votes")
    op.drop_table("users")
    op.drop_table("tags")
    op.drop_table("subscriptions")
    op.drop_table("posts")
    op.drop_table("pageviews")
    op.drop_table("emails")
    op.drop_table("comments")
    op.drop_table("assoc_post_group")
    op.drop_table("assoc_group_user")
    op.drop_table("groups")
    op.drop_table("index_metadata")
    op.drop_table("errorlog")
    op.drop_table("download_reasons")
    op.drop_table("topic")

    bind = op.get_bind()
    session = orm.Session(bind=bind)
    session.query(Group).filter(name="admin").delete()
    session.commit()
