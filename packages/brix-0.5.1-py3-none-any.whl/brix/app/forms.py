"""Brix flask app forms"""

from flask_wtf import FlaskForm
from wtforms import StringField, RadioField, IntegerField
from wtforms.fields.html5 import URLField
from wtforms.validators import DataRequired, url
from wtforms.widgets import TextArea


class FeedbackForm(FlaskForm):
    """
    User feedback form
    """
    feedback = StringField(
        "How we can improve",
        validators=[DataRequired()],
        widget=TextArea()
    )
    location = URLField(
        validators=[
            url(),
            DataRequired()
        ]
    )
    screen_height = IntegerField()
    screen_width = IntegerField()


class DownloadReasonForm(FlaskForm):
    """
    User feedback for post downloading
    """
    reason = RadioField("Reason",
                        choices=(
                            ("project", "For my project"),
                            ("research", "For my research"),
                            ("learning", "For my learning"),
                            ("other", "Other reason")
                        ))
    project = StringField(
        "Project name:",
    )
    custom = StringField(
        "Please specify:",
        widget=TextArea()
    )
