var feedback = (function () {
    function post() {
        var data = helpersJx.getFormData($("#feedback_form"));

        data["location"] = location.href;
        data["screen_height"] = window.screen.height;
        data["screen_width"] = window.screen.width;

        $.ajax({
            url: "/feedback",
            method: "POST",
            data: JSON.stringify(data),
            contentType: "application/json",
            dataType: "json",
        }).done(function() {
            $("#feedback_modal").modal("hide");
            $("#feedback_form #feedback").val("");
        }).fail(function() {
            $("#feedback_modal").modal("hide");
        })
    }

    return {
        post: post
    }
}());
