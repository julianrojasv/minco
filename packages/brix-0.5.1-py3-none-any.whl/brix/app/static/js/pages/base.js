$(document).ready(function () {
    $("#searchbar")[0].setSelectionRange(1000, 1000);

    var postSuggestions = new Bloodhound({
        datumTokenizer: function (datum) {
            return Bloodhound.tokenizers.whitespace(datum.value);
        },
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            wildcard: "%QUERY",
            url: "/ajax/index/typeahead?search=%QUERY",
            transform: function (response) {
                return response["posts"]
            },
        }
    });

    var authorSuggestions = new Bloodhound({
        datumTokenizer: function (datum) {
            return Bloodhound.tokenizers.whitespace(datum.value);
        },
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            wildcard: "%QUERY",
            url: "/ajax/index/typeahead?search=%QUERY",
            transform: function (response) {
                return response["authors"]
            },
        }
    });

    var tagsSuggestions = new Bloodhound({
        datumTokenizer: function (datum) {
            return Bloodhound.tokenizers.whitespace(datum.value);
        },
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            wildcard: "%QUERY",
            url: "/ajax/index/typeahead?search=%QUERY",
            transform: function (response) {
                return response["tags"]
            },
        }
    });

    postSuggestions.initialize();
    authorSuggestions.initialize();
    tagsSuggestions.initialize();

    $("#searchbar").typeahead({
            hint: false,
            highlight: true,
            minLength: 3
        }, {
            display: function (item) {
                return item.title
            },
            templates: {
                empty: "<div class='tt-not-found'>No results</div>",
                header: "<h3 class='typeahead-header'>Brix</h3>",
                suggestion: function (data) {
                    return "<p><img src='/static/images/python_l.svg'><span>" + data.title + "</span></p>";
                }
            },
            source: postSuggestions.ttAdapter()
        },
        {
            display: function (item) {
                return item.name
            },
            templates: {
                header: "<h3 class='typeahead-header'>Authors</h3>",
                suggestion: function (data) {
                    var url = data.avatar ? data.avatar : "/static/images/profile_photo_default.png";
                    return "<p><img class='avatar' src='" + url + "'><span style='margin-left: 0px'>" + data.name + "</span></p>";
                }
            },
            source: authorSuggestions.ttAdapter()
        },
        {
            display: function (item) {
                return item.name
            },
            templates: {
                header: "<h3 class='typeahead-header'>Tags</h3>",
                suggestion: function (data) {
                    return "<p style='margin-top: 16px'><img src='/static/images/labels.svg'><span class='label-tag'>#" + data.name + "</span></p>";
                }
            },
            source: tagsSuggestions.ttAdapter()
        }
    );

    $('#searchbar').bind("typeahead:select", function (obj, datum, name) {
        if (datum["type"] === "post") {
            window.location = "/post/" + encodeURIComponent(datum.path);
        } else if (datum["type"] === "author") {
            window.location = '/author/' + encodeURIComponent(datum.identifier);
        } else if (datum["type"] === "tag") {
            window.location = '/tag/' + encodeURIComponent(datum.name);
        }
    });

    $('#searchbar').keypress(function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            var path = document.location.pathname;
            window.location = '/feed?filters=' + $('#searchbar').val()
        }
    });

    var padding = $('.tt-menu').outerWidth()
    $('.tt-menu').width($('#searchbar').width() + padding + "px");

    $(".search-button").click(function() {
       $("#searchbar").focus();
       $("#typeahead-close").removeClass("hidden");
    });

    $("#searchbar").click(function () {
        $("#typeahead-close").removeClass("hidden");
    });

    $("#searchbar").blur(function (event) {
        const value = event.target.value;

        if (!value) {
            $("#typeahead-close").addClass("hidden");
        }
    });

    $("#typeahead-close").click(function() {
        $(this).addClass("hidden");
        $("#searchbar")
            .typeahead("close")
            .typeahead("val", "")
            .blur();
        $(".search-button").removeAttr("style");
    });

    function update_panel_widths(panel_name) {
        if (window.matchMedia("(min-width: 1200px)").matches) {
            $(panel_name).width($(panel_name).parent().width());
            $(panel_name).css("position", "fixed");
        } else {
            $(panel_name).width('auto');
            $(panel_name).css("position", "relative");
        }
    }

    // update_panel_widths('#panel-left');
    // update_panel_widths('#panel-right');
    $(window).resize(update_panel_widths.bind(null, '#panel-left'));
    $(window).resize(update_panel_widths.bind(null, '#panel-right'));
    $('body').tooltip({
        selector: '[data-toggle="tooltip"]'
    });

    window.addEventListener('DOMContentLoaded', update_panel_widths.bind(null, '#panel-left'));

    function onAjaxErrorHandler(event, xhr) {
      if (xhr.status === 401 || xhr.status === 403) {
        window.location.reload();
      }
    }

    $(document).on('ajaxError', onAjaxErrorHandler);
});
