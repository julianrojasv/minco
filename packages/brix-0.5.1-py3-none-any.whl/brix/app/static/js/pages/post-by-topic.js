$(document).ready(function () {
    if ($('#paginationTop').length) {
        document.getElementById("feedHeaders").style.marginTop = '34px';
    }

    $(".dropdown-item").click(function() {
        var filterId = $(this).attr('id');

        var currUrl = window.location.href;
        if (currUrl.includes("sort_by")) {
            var indexSort = currUrl.indexOf('sort_by') - 1;
            currUrl = currUrl.slice(0, indexSort);
        }

        if (filterId === "mostRecent") {
            var sort = "sort_by=created_at"
        } else if (filterId === "mostVieved") {
            var sort = "sort_by=views"
        } else if (filterId === "mostLiked") {
            var sort = "sort_by=upvotes"
        }

        if (currUrl.includes("topic")) {
            var url = currUrl + "&" + sort;
        } else {
            var url = currUrl + "?" + sort;
        }

        var indexPath = url.indexOf(window.location.pathname);
        var ajaxUrl = url.slice(0, indexPath) + '/ajax' + url.slice(indexPath);

        $.ajax({
            type: "GET",
            url: ajaxUrl,
            async: false,
            success: function(data) {
                $('#div-post-topic').html(data);
                window.history.pushState({path:url},'',url);
            }
        });
    });
});
