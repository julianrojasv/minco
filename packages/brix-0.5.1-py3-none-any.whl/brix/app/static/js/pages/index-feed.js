(function($) {

    function em_to_px(parent, em) {
        return parseFloat(getComputedStyle(parent).fontSize) * em;
    }

    function posts_open(event) {
        var is_mac = navigator.platform.indexOf('Mac') != -1;
        if (is_mac && event.metaKey || !is_mac && event.ctrlKey) {
            window.open($(this).data('url'), '_blank');
        } else {
            window.location = $(this).data('url');
        }

    }

    function posts_expand_tldr(event) {
        event.stopPropagation();
        var tldr = $(this).parent().children('.feed-tldr');

        if (! tldr.data('expanded') ) {
            // Compute height of nested (and potentially masked elements) elements
            var height = $(tldr).children().map(function(undefined, elem) { return $(elem).outerHeight() + 5; }).toArray().reduce(function(prev, curr) { return prev + curr; }, 0);

            $(tldr).animate({"height": Math.max(height + 25, em_to_px(this, 5) + 5)}, 400);
            $(tldr).data('expanded', true);
            $(this).html('<a>- Show Less</a>');
        } else {
            $(tldr).animate({"height": em_to_px(this, 5) + 5}, 400);
            $(tldr).data('expanded', false);
            $(this).html('<a>+ Show More</a>');
        }
    }

    $("#topic-close").click(function() {
        $.ajax({
            type: "GET",
            url: '/feed',
            async: false,
        });
        window.location = '/feed'
    });

    function onloadFunction() {
        var indexTopic = window.location.href.indexOf('topic=') + 6;
        var topicId = window.location.href.slice(indexTopic, indexTopic+1);

        if (!isNaN(topicId)){
            var all = document.getElementsByClassName('topic');
            document.getElementById('topic-close').style.display = 'inline';

            for (var i = 0; i < all.length; i++) {
                if (all[i].id !== topicId){
                    all[i].closest('tr').style.opacity = 0.3;
                    all[i].closest('tr').style.borderBottom = '';
                } else {
                    all[i].closest('tr').style.borderBottom = "1px solid #000000";
                    all[i].closest('tr').style.opacity = 1.0;
                }
            }
        }
    }

    window.onload = function() {onloadFunction()};
    $("body").on("click", ".feed-post .feed-title", posts_open);
    $("body").on("click", ".feed-post .feed-tldr-expander", posts_expand_tldr);

})(jQuery);
