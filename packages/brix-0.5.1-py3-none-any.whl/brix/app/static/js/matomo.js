var _paq = _paq || [];
/* tracker methods like "setCustomDimension" should be called before "trackPageView" */
fetch('/api/me')
  .then(r => r.json())
  .then(user => _paq.push(['setUserId', user.username]))
  .finally(() => {
    _paq.push(['trackPageView']);
    _paq.push(['enableLinkTracking']);
    _paq.push(['enableHeartBeatTimer']);
  });
(function() {
  var u="//tracking.quantumblack.com/";
  _paq.push(['setTrackerUrl', u+'piwik.php']);
  _paq.push(['setSiteId', '18']);    // 18 is the siteId for brix.qbalchemy.com
  var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
  g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  // pass user id to piwik
})();
