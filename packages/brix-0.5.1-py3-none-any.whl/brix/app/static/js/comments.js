var commentsJx = (function(){

  function postComment(comment_author, post_author, post_title, post_path) {
    var comment_text = $('#comment-text').val();

    if (comment_text === '') {
      return;
    }

    var postContent = {};
    postContent.what = 'comment';
    postContent.author = comment_author;
    postContent.text = comment_text;
    postContent.post_author = post_author;
    postContent.post_title = post_title;

    $.ajax({
        type: "POST",
        data: JSON.stringify(postContent),
        contentType: "application/json",
        url: '/comment?path=' + encodeURI(post_path),
        success: function(resp) {
            $('#commentsBlock').html(resp);
        },
        async: false
    });
    document.getElementById("comment-text").value = "";
  }


  function deleteComment(post_path, comment_id){
    $.ajax({
        type:"GET",
        url: "/delete_comment?comment_id=" + comment_id,
        async: false,
        success: function(resp) {
            $('#commentsBlock').html(resp);
        }
    });
  }


  return {
    postComment: postComment,
    deleteComment: deleteComment
  }

}());
