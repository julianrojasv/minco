var downloadFeedback = (function () {
    var $downloadFeedbackModal = $("#download_feedback_modal");
    var $reasonProjectInputBlock = $("#download_reason_project-input-block");
    var $reasonOtherInputBlock = $("#download_reason_other-input-block");
    var $downloadLink;

    function post() {
        var data = JSON.stringify(helpersJx.getFormData($("form#download__feedback")));

        $.ajax({
            url: "/ajax/download/feedback",
            method: "POST",
            data: data,
            contentType: "application/json",
            dataType: "json",
        }).done(function (data) {
            $downloadFeedbackModal.modal("hide");
            $("#feedback_form #feedback").val("");
            window.location.href = $downloadLink.attr("href") + "&reason_id=" + data["reason_id"]
        })
    }

    function handleModal(el) {
        console.log(el)
        $downloadLink = $(el);
        $downloadFeedbackModal.modal();
        $("#download__feedback .radio input").change(function() {
            $.each([$reasonOtherInputBlock, $reasonProjectInputBlock], function(index, value) {
                this.addClass("hidden");
                this.find("input").val("");
            });
            if ($(this).val() === "project") {
                $reasonProjectInputBlock.removeClass("hidden");
            } else if ($(this).val() === "other") {
                $reasonOtherInputBlock.removeClass("hidden");
            }
            $("form#download__feedback button[type='submit']").removeAttr("disabled")
        });
        // prevent actual download
        return false;
    }

    return {
        handleModal: handleModal,
        post: post,
    }
})();
