(function () {
  const redirectMessageLSKey = 'IS_MESSAGE_VIEWED';
  const recipesDomain = 'recipes.quantumblack.com';
  const recipesDevelopDomain = 'recipes-develop.quantumblack.com';

  const brixDomain = 'brix.quantumblack.com';
  const brixDevelopDomain = 'brix-develop.quantumblack.com';

  const hostname = location.hostname;

  if (hostname.includes(recipesDevelopDomain)) {
    window.location = location.protocol + '//' + brixDevelopDomain;
  } else if (hostname.includes(recipesDomain)) {
    window.location = location.protocol + '//' + brixDomain;
  }

  document.addEventListener('DOMContentLoaded', function () {
    const isMessageViewed = localStorage.getItem(redirectMessageLSKey);

    if (isMessageViewed === 'True') {
      return;
    }

    document
      .querySelector('.redirect-message')
      .classList
      .remove('hidden');

    function onCloseMessageHandler() {
      localStorage.setItem(redirectMessageLSKey, 'True');
      document.querySelector('.redirect-message').classList.add('hidden');
    }

    document
      .querySelector('.redirect-message__close')
      .addEventListener('click', onCloseMessageHandler);
  })
})();
