# Todo need to split to split this file  # pylint:disable=too-many-lines
"""SQLAlchemy models"""

import datetime
import logging
import os
import sys
import traceback
from collections import defaultdict
from enum import Enum
from typing import Callable, List, Tuple, Union

from flask import current_app, request
from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from future.utils import raise_with_traceback
from sqlalchemy import distinct, func, select, text  # pylint:disable=unused-import
from sqlalchemy.ext.associationproxy import association_proxy
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.ext.orderinglist import ordering_list
from sqlalchemy.orm import RelationshipProperty
from sqlalchemy.sql import Select
from werkzeug.utils import cached_property

from brix import __version__
from brix.app.utils.user import get_or_create
from brix.repo import KnowledgeRepository

from brix.post import KnowledgePost
from brix.app.proxies import current_repo, current_user, db_session
from brix.app.utils.models import unique_constructor
from brix.app.utils.search import get_keywords

logger = logging.getLogger(__name__)


db = SQLAlchemy()


class IndexMetadata(db.Model):
    """ Table that contains records for managing indexing of the repository"""

    __tablename__ = "index_metadata"

    id = db.Column(db.Integer, nullable=False, primary_key=True)
    type = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(512), nullable=False)
    value = db.Column(db.String(512), nullable=True)
    updated_at = db.Column(
        db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow
    )

    @classmethod
    def get(cls, type_: str, name: str, default: "IndexMetadata" = None) -> str:
        """
        get value of the first record filtered by given params
        Args:
            type_: IndexMetadata type
            name: IndexMetadata name
            default: default value if no record with given params

        Returns:
            IndexMetadata object value or None
        """
        m = (
            db_session.query(IndexMetadata)
            .filter(IndexMetadata.type == type_)
            .filter(IndexMetadata.name == name)
            .first()
        )
        if m is not None:
            return m.value
        return default

    @classmethod
    def set(cls, type_: str, name: str, value: str):
        """
        set value to the first record filtered by given params
        Args:
            type_: IndexMetadata type
            name: IndexMetadata name
            value: IndexMetadata value
        """
        m = (
            db_session.query(IndexMetadata)
            .filter(IndexMetadata.type == type_)
            .filter(IndexMetadata.name == name)
            .first()
        )
        if m is not None:
            m.value = value
            m.updated_at = datetime.datetime.utcnow()
        else:
            m = IndexMetadata(
                type=type_,
                name=name,
                value=value,
                updated_at=datetime.datetime.utcnow(),
            )
            db_session.add(m)

    @classmethod
    def get_last_update(cls, type_: str, name: str) -> str:
        """
        get updated_at of the first record filtered by given params
        Args:
            type_: IndexMetadata type
            name: IndexMetadata name

        Returns:
            IndexMetadata object updated_at or None
        """
        m = (
            db_session.query(IndexMetadata)
            .filter(IndexMetadata.type == type_)
            .filter(IndexMetadata.name == name)
            .first()
        )
        if m is not None:
            return m.updated_at
        return None


class PostAuthorAssoc(db.Model):  # pylint:disable=too-few-public-methods
    """ Many to many table between posts and users"""

    __tablename__ = "assoc_post_author"

    post_id = db.Column(
        db.Integer, db.ForeignKey("posts.id"), nullable=False, primary_key=True
    )
    user_id = db.Column(
        db.Integer, db.ForeignKey("users.id"), nullable=False, primary_key=True
    )
    order = db.Column(db.Integer)

    post = db.relationship("Post", lazy="joined")
    author = db.relationship("User", lazy="joined")


assoc_post_tag = db.Table(  # pylint:disable=invalid-name
    "assoc_post_tag",
    db.Model.metadata,
    db.Column("post_id", db.Integer, db.ForeignKey("posts.id")),
    db.Column("tag_id", db.Integer, db.ForeignKey("tags.id")),
)

assoc_post_group = db.Table(  # pylint:disable=invalid-name
    "assoc_post_group",
    db.Model.metadata,
    db.Column("post_id", db.Integer, db.ForeignKey("posts.id")),
    db.Column("group_id", db.Integer, db.ForeignKey("groups.id")),
)

assoc_group_user = db.Table(  # pylint:disable=invalid-name
    "assoc_group_user",
    db.Model.metadata,
    db.Column("group_id", db.Integer, db.ForeignKey("groups.id")),
    db.Column("user_id", db.Integer, db.ForeignKey("users.id")),
)


class Comment(db.Model):  # pylint:disable=too-few-public-methods
    """Post comments model"""

    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    post_id = db.Column(db.Integer)
    text = db.Column(db.Text)
    type = db.Column(db.String(100), default="post")
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())


class ErrorLog(db.Model):
    """Error model for collecting error"""

    __tablename__ = "errorlog"

    id = db.Column(db.Integer, primary_key=True)
    function = db.Column(db.String(100))
    location = db.Column(db.String(255))
    message = db.Column(db.Text())
    traceback = db.Column(db.Text())
    version = db.Column(db.String(100), default=__version__)
    created_at = db.Column(db.DateTime, default=func.now())

    @classmethod
    def from_exception(cls, exc: Exception) -> "ErrorLog":
        """
        Generate error from exception object
        Args:
            exc: python exception

        Returns:
            Not persistent instance
        """
        trb = sys.exc_info()[-1]
        filename, linenumber, function, _ = traceback.extract_tb(sys.exc_info()[-1])[-1]
        filename = os.path.relpath(
            filename, os.path.join(os.path.dirname(__file__), "..")
        )
        return ErrorLog(
            function=function,
            location="{}:{}".format(filename, linenumber),
            message="{}: {}".format(
                exc.__class__.__name__, "; ".join(str(a) for a in exc.args)
            ),
            traceback="\n".join(traceback.format_tb(trb)),
        )

    @classmethod
    def logged(cls, function: Callable) -> Callable:
        """
        Decorator that catch errors and save them to ErrorLog
        Args:
            function: Function to decorate

        Returns:
            Wrapped function
        """

        def wrapped(*args, **kwargs):
            try:
                return function(*args, **kwargs)
            except Exception as exc:  # pylint:disable=broad-except
                db_session.rollback()
                db_session.add(ErrorLog.from_exception(exc))
                db_session.commit()
                raise_with_traceback(exc)

        return wrapped


class PageView(db.Model):  # pylint:disable=too-few-public-methods
    """Model for collecting user views"""

    __tablename__ = "pageviews"

    id = db.Column(db.Integer, primary_key=True)
    id_errorlog = db.Column(db.Integer)
    page = db.Column(db.String(512))
    endpoint = db.Column(db.String(255))
    user_id = db.Column(db.Integer)
    object_id = db.Column(db.Integer)
    object_type = db.Column(db.String(100))
    object_action = db.Column(db.String(100))
    ip_address = db.Column(db.String(64))
    created_at = db.Column(db.DateTime, default=func.now())
    version = db.Column(db.String(100), default=__version__)

    class logged:  # pylint:disable=invalid-name
        """Class decorator for collecting PageViews from flask view"""

        def __init__(self, route: str, object_extractor: Callable = None):
            """
            Args:
                route: route to catch
                object_extractor: function for getting object from flask request
            """
            self._route = route
            self._object_extractor = object_extractor

        def __getattr__(self, attr):
            return getattr(self._route, attr)

        def __call__(self, *args, **kwargs):
            log = PageView(
                page=request.full_path,
                endpoint=request.endpoint,
                user_id=current_user.id,
                ip_address=request.remote_addr,
                version=__version__,
            )
            errorlog = None
            (
                log.object_id,
                log.object_type,
                log.object_action,
                reextract_after_request,
            ) = self.extract_objects(*args, **kwargs)
            db_session.add(log)  # Add log here to ensure pageviews are accurate

            try:
                return self._route(*args, **kwargs)
            except Exception as e:  # pylint:disable=broad-except
                db_session.rollback()  # Ensure no lingering database changes remain after crashed route
                db_session.add(log)
                errorlog = ErrorLog.from_exception(e)
                db_session.add(errorlog)
                db_session.commit()
                raise_with_traceback(e)
            finally:
                # Extract object id and type after response generated (if requested) to ensure
                # most recent data is collected
                if reextract_after_request:
                    (
                        log.object_id,
                        log.object_type,
                        log.object_action,
                        _,
                    ) = self.extract_objects(*args, **kwargs)

                if errorlog is not None:
                    log.id_errorlog = errorlog.id
                db_session.add(log)
                db_session.commit()

        def object_extractor(self, extractor: Callable) -> "logged":
            """
            Set callable that extracts object
            Args:
                extractor: function for object extraction that returns dict

            Returns:
                This object

            """
            self._object_extractor = extractor
            return self

        def extract_objects(self, *args, **kwargs) -> Tuple:
            """
            Get dict with needed object from the decorated view
            Args:
                *args : Arbitrary argument list for object_extractor
                **kwargs: Arbitrary keyword arguments for object_extractor

            Returns:
                Tuple with `id`, `type`, `action` and `may_change` keys
            """
            if self._object_extractor is None:
                return None, None, None, False
            try:
                object_info = self._object_extractor(*args, **kwargs)
            except Exception as exc:  # pylint:disable=broad-except
                logger.warning("Error using object extractor: %s", str(exc))
                object_info = {"id": (-1), "type": None}
            assert isinstance(
                object_info, dict
            ), "Object extractors must return a dictionary."

            message = (
                "Object extractors must at least include the keys 'id' "
                "and 'type', and optionally 'action' and 'may_change'. Was provided with: {}"
            )
            assert not {"id", "type"}.difference(object_info.keys()) and not set(
                object_info.keys()
            ).difference(["id", "type", "action", "may_change"]), message.format(
                str(list(object_info.keys()))
            )
            object_info = defaultdict(lambda: None, object_info)
            return (
                object_info["id"],
                object_info["type"],
                object_info["action"],
                object_info["may_change"] or False,
            )


class Vote(db.Model):  # pylint:disable=too-few-public-methods
    """Model for post votes"""

    __tablename__ = "votes"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    object_id = db.Column(db.Integer)
    object_type = db.Column(db.String(100), default="post")
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())


@unique_constructor(
    lambda identifier: identifier,
    lambda query, identifier: query.filter(User.identifier == identifier),
)
class User(db.Model, UserMixin):
    """User model"""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=func.now())

    identifier = db.Column(
        db.String(500), unique=True, nullable=False
    )  # Unique identifier across all login methods

    username = db.Column(
        db.String(500)
    )  # Username used to log in (may differ from identifier)
    password = db.Column(db.String(500))  # Password for local logins

    name = db.Column(db.String(500))  # Name as determined by auth method
    preferred_name = db.Column(db.String(500))  # Name as determined by user preferences

    email = db.Column(db.String(500))  # Email address
    avatar_uri = db.Column(db.Text())  # Either external url or data uri
    active = db.Column(db.Boolean, default=True)

    last_login_at = db.Column(db.DateTime)  # Date of last login

    _posts_assoc = db.relationship("PostAuthorAssoc", lazy="subquery")
    posts = association_proxy(
        "_posts_assoc", "post"
    )  # This property should not directly modified

    _groups = db.relationship(
        "Group", secondary=assoc_group_user, backref="groups", lazy="dynamic"
    )

    def __str__(self):
        return f"User: {self.format_name}"

    @hybrid_property
    def groups(self) -> RelationshipProperty:
        """
        User groups
        Returns:
            Groups: Groups of user

        """
        return self._groups

    @property
    def is_active(self) -> bool:
        """
        # Method overrides for the UserMixin class for flask_login

        Returns:
            True if user is active else False

        """
        return self.active

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def is_anonymous(self) -> bool:
        return False

    @property
    def is_admin(self) -> bool:
        """
        Check if user is in admin group
        Returns:
            True if user has `admin` group else False

        """
        return self.groups.filter(  # pylint:disable=no-member
            Group.name == "admin"
        ).scalar()

    def get_id(self):
        return self.identifier

    can_logout = True

    # Other useful methods
    @property
    def format_name(self) -> str:
        """
        Check for user name in `preferred_name` and `name`
        Returns:
            User name
        """
        return self.preferred_name or self.name or self.identifier

    @property
    def subscriptions(self) -> List:  # TODO: make attribute style naming
        """Get the subscriptions associated with a user.
        Returns:
             List of strings of tag_names
        """
        tags_subquery = (
            Subscription.query.filter(
                Subscription.user_id == self.id, Subscription.object_type == "tag"
            )
            .with_entities(Subscription.object_id)
            .subquery("tags")
        )
        return [
            t
            for t, in Tag.query.filter(Tag.id.in_(tags_subquery))
            .with_entities(Tag.name)
            .all()
        ]

    @property
    def liked_posts(self) -> List:
        """
        Returns:
            list: Posts that a user has liked
        """
        votes = db_session.query(Vote).filter(Vote.user_id == self.id).all()
        post_ids = [vote.object_id for vote in votes]
        if not post_ids:
            return []
        excluded_tags = current_app.config.get("EXCLUDED_TAGS", [])
        posts = (
            db_session.query(Post)
            .filter(Post.id.in_(post_ids))
            .filter(
                ~Post.tags.any(Tag.name.in_(excluded_tags))  # pylint:disable=no-member
            )
            .all()
        )
        return posts

    @property
    def posts_vote_count(self) -> int:
        """
        Vote count of all posts written by user
        """
        return (
            db_session.query(Vote)
            .filter(
                Vote.object_id.in_([post.id for post in self.posts]),
                Vote.object_type == "post",
            )
            .count()
        )


@unique_constructor(
    lambda name: name, lambda query, name: query.filter(Tag.name == name)
)
class Tag(db.Model):
    """Post tags model"""

    __tablename__ = "tags"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(500))
    _description = db.Column("description", db.Text())
    created_at = db.Column(db.DateTime, default=func.now())

    @hybrid_property
    def description(self):
        """
        Returns:
            str: Tag `_description` or modified `name`
        """
        if self._description:
            return self._description
        return "All posts with tag '{}'.".format(self.name)

    @description.expression
    def description(self):
        """
        # Todo have no idea why it raise NotImplementedError
        """
        raise NotImplementedError

    @cached_property
    def related_tags(self) -> List["Tag"]:
        """
        Get tags from the posts of the particular tag ordered by number of appearance in posts
        """
        tags = (
            db_session.query(Tag, func.count(assoc_post_tag.c.post_id).label("total"))
            .join(assoc_post_tag)
            .filter(Tag.id != self.id)
            .group_by(Tag)
            .order_by(text("total DESC"))
        )
        return [t[0] for t in tags.all() if set(t[0].posts) & set(self.posts)]


class Subscription(db.Model):  # pylint:disable=too-few-public-methods
    """ Post subscriptions model"""

    __tablename__ = "subscriptions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    object_id = db.Column(db.Integer)
    object_type = db.Column(db.String(100))  # Currently just tag
    created_at = db.Column(db.DateTime, default=func.now())


class Topic(db.Model):  # pylint:disable=too-few-public-methods
    """Model for post's topic"""

    __tablename__ = "topic"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(500), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now())

    def get_or_create(self, session, **kwargs):
        instance = session.query(self.__class__).filter_by(**kwargs).first()
        if instance:
            return instance
        else:
            instance = self.__class__(**kwargs)
            session.add(instance)
            session.commit()
            return instance


class Post(db.Model):  # pylint:disable=too-many-instance-attributes
    """ Post model"""

    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(100), unique=True)
    path = db.Column(db.String(512))
    project = db.Column(db.String(512), nullable=True)  # DEPRECATED
    repository = db.Column(db.String(512))
    revision = db.Column(db.Integer())

    title = db.Column(db.Text())
    subtitle = db.Column(db.Text())
    tldr = db.Column(db.Text)
    keywords = db.Column(db.Text)
    thumbnail = db.Column(db.Text())

    private = db.Column(db.Integer())

    created_at = db.Column(db.DateTime, default=func.now())
    updated_at = db.Column(db.DateTime, default=func.now())
    coverage = db.Column(
        db.Float(), nullable=False, default=0, server_default=text("0")
    )

    _authors_assoc = db.relationship(
        "PostAuthorAssoc",
        order_by="PostAuthorAssoc.order",
        collection_class=ordering_list("order"),
        cascade="all, delete-orphan",
    )
    _authors = association_proxy(
        "_authors_assoc",
        "author",
        creator=lambda author: PostAuthorAssoc(author=author),
    )

    topic_id = db.Column(db.Integer, db.ForeignKey("topic.id"))
    _topic = db.relationship(
        "Topic", primaryjoin="and_(foreign(Post.topic_id)==Topic.id, )"
    )

    def __str__(self) -> str:
        """Post object representation"""
        return self.title

    def set_topic(self, session, path):
        main_topic = (path.split("/")[0]).replace("_", " ").capitalize()
        topic = Topic().get_or_create(session, name=main_topic)
        self.topic_id = topic.id

    @hybrid_property
    def authors(self) -> List[User]:
        """
        Post authors
        Returns:
            Authors of the post
        """
        return self._authors

    @authors.setter
    def authors(self, authors: List[Union[User, str]]):
        """
        Sets post authors
        Args:
            authors: List of User instances or strings
        """
        user_objs = []

        for author in authors:
            if not isinstance(author, User):
                author = author.strip()
                # ToDo maybe should add some validation here
                author = User(identifier=author)
            user_objs.append(author)

        self._authors = user_objs

    @hybrid_property
    def authors_string(self) -> str:
        """
        Returns:
            String of comma separated post authors name
        """
        return ", ".join([author.format_name for author in self.authors])

    @authors_string.expression
    def authors_string(self):
        """
        # Todo have no idea why it raise NotImplementedError
        """
        raise NotImplementedError

    _tags = db.relationship(
        "Tag", secondary=assoc_post_tag, backref="posts", lazy="subquery"
    )

    @hybrid_property
    def tags(self) -> List[Tag]:
        """
        Returns:
            Tag: Tags of the post
        """
        return self._tags

    @tags.setter
    def tags(self, tags: List[Union[Tag, str]]):
        """
        Sets the tags of the post to the tags given in comma delimited string
        form in tags_string
        Args:
            tags: List of Tag objects or string
        """
        tag_objs = []

        for tag in tags:
            if not isinstance(tag, Tag):
                tag = tag.strip()
                if tag[0] == "#":
                    tag = tag[1:]
                tag = Tag(name=tag)
            tag_objs.append(tag)

        self._tags = tag_objs

    @property
    def contains_excluded_tag(self) -> bool:
        """
        Returns:
            True if post has tag from app `EXCLUDED_TAGS` else False
        """
        excluded_tags = current_app.config.get("EXCLUDED_TAGS", [])
        return any([tag.name in excluded_tags for tag in self.tags])

    _groups = db.relationship(
        "Group", secondary=assoc_post_group, backref="posts", lazy="subquery"
    )

    @hybrid_property
    def groups(self) -> List["Group"]:
        """
        Post groups. Currently not used
        Returns:
            Groups of post
        """
        return self._groups

    @groups.setter
    def groups(self, groups: List[Union["Group", str]]):
        """
        Sets the groups of the post to the given group name. Adds post authors to
        that group

        Args:
            groups: list of Group or string names for new groups
        """
        # given a list of group_names, we add it.
        group_objs = []

        for group in groups:
            if not isinstance(group, Group):
                group = Group(name=group.strip())
            group_objs.append(group)

        # create an implicit group, group_post.id, to add
        # single users to
        group = Group(name=":post_group_" + str(self.id))

        # this created group should have the author associated with it
        # so they can add people to the post
        group.users = self.authors
        group_objs.append(group)

        self._groups = group_objs

    _status = db.Column("status", db.Integer(), default=0)

    @hybrid_property
    def status(self) -> str:
        """
        Returns:
            Post status string representation
        """
        return current_repo.PostStatus(self._status or 0)

    @status.expression
    def status(self):
        """
        SQLAlchemy expression to filter by _status property
        Returns:
            func.coalesce: for status property
        """
        return func.coalesce(self._status, 0)

    @status.setter
    def status(self, status: str):
        """
        Set `_status` from PostStatus status value
        Args:
            status: post status
        """
        if status is None:
            self._status = None
        else:
            assert isinstance(
                status, KnowledgeRepository.PostStatus
            ), "Status must be an instance of KnowledgeRepository.PostStatus.Status or None"
            self._status = status.value

    @hybrid_property
    def is_published(self) -> bool:
        """
        Returns:
            True if post status is PUBLISHED else False
        """
        return self.status == current_repo.PostStatus.PUBLISHED

    @is_published.expression
    def is_published(self):
        """
        SQLAlchemy expression to filter by is_published property
        Returns:
            func.coalesce: for is_published property
        """
        return func.coalesce(self._status, 0) == current_repo.PostStatus.PUBLISHED.value

    _views = db.relationship(
        "PageView",
        lazy="dynamic",
        primaryjoin="and_(foreign(PageView.object_id)==Post.id, "
        "PageView.object_type=='post',"
        "PageView.object_action=='view')",
    )

    @hybrid_property
    def views(self) -> RelationshipProperty:
        """
        Returns:
            All post views
        """
        return self._views.all()

    @hybrid_property
    def view_count(self) -> int:
        """
        Returns:
            Sum of post views
        """
        return self._views.count()

    @view_count.expression
    def view_count(self) -> Select:
        """
        Returns:
            select: expression for filter by view_count property
        """
        return (
            select([func.count(PageView.id)])
            .where(PageView.object_id == self.id)
            .where(PageView.object_type == "post")
            .label("view_count")
        )

    @hybrid_property
    def view_user_count(self) -> int:
        """
        Returns:
            Sum of distinct per user view counts
        """
        return (
            db_session.query(func.count(distinct(PageView.user_id)))
            .filter(PageView.object_id == self.id)
            .filter(PageView.object_type == "post")
            .scalar()
        )

    @view_user_count.expression
    def view_user_count(self) -> Select:
        """
        Returns:
            Expression for filter by view_user_count property
        """
        return (
            select([func.count(distinct(PageView.user_id))])
            .where(PageView.object_id == self.id)
            .where(PageView.object_type == "post")
            .label("view_user_count")
        )

    _votes = db.relationship(
        "Vote",
        lazy="dynamic",
        primaryjoin="and_(foreign(Vote.object_id)==Post.id, "
        "Vote.object_type=='post')",
    )

    @hybrid_property
    def votes(self):
        """All post votes"""
        return self._votes.all()

    @hybrid_property
    def vote_count(self) -> int:
        """
        Given the path of a post, return the total likes
        Returns:
            Sum of post vote
        """
        return self._votes.count()

    @vote_count.expression
    def vote_count(self) -> Select:
        """
        Returns:
            Expression for filter by vote_count property
        """
        return (
            select([func.count(Vote.id)])
            .where(Vote.object_id == self.id)
            .where(Vote.object_type == "post")
            .label("vote_count")
        )

    def vote_counted_for_user(self, user_id: int) -> bool:
        """
        Args:
            user_id: User.id
        Returns:
            True if user with given user_id voted for post else False
        """
        return (
            db_session.query(Vote)
            .filter(
                Vote.object_id == self.id,
                Vote.object_type == "post",
                Vote.user_id == user_id,
            )
            .first()
        ) is not None

    _comments = db.relationship(
        "Comment",
        lazy="dynamic",
        primaryjoin="and_(foreign(Comment.post_id)==Post.id, " "Comment.type=='post')",
    )

    @hybrid_property
    def comments(self):
        """All post comments"""
        return self._comments.all()

    @hybrid_property
    def comment_count(self) -> int:
        """ Given the path of the a post, return the total comments """
        return self._comments.count()

    @comment_count.expression
    def comment_count(self) -> Select:
        """Expression to filter by comment count"""
        return (
            select([func.count(Comment.id)])
            .where(Comment.post_id == self.id)
            .where(Comment.object_type == "post")
            .label("comments_count")
        )

    def comments_counted_for_user(self, user_id: int) -> bool:
        """
        Args:
            user_id: User.id
        Returns:
            True if user with given user_id commented post else False
        """
        return (
            db_session.query(Comment)
            .filter(
                Comment.post_id == self.id,
                Comment.type == "post",
                Comment.user_id == user_id,
            )
            .first()
        ) is not None

    @property
    def kp(self):
        """KnowledgePost of the post"""
        return current_repo.post(self.path)

    @property
    def text(self) -> str:
        """
        Returns:
            KnowledgePost representation
        """
        return self.kp.read()

    _downloads = db.relationship(
        "PageView",
        lazy="dynamic",
        primaryjoin="and_(foreign(PageView.object_id)==Post.id, "
        "PageView.object_type=='post',"
        "PageView.object_action=='download')",
    )

    @hybrid_property
    def download_count(self) -> int:
        """Total post downloads"""
        return self._downloads.count()

    @hybrid_property
    def download_user_count(self) -> int:
        """Distinct post downloads"""
        return (
            db_session.query(func.count(distinct(PageView.user_id)))
            .filter(
                PageView.object_id == self.id,
                PageView.object_type == "post",
                PageView.object_action == "download",
            )
            .scalar()
        )

    @download_user_count.expression
    def download_user_count(self) -> Select:
        """Expression to filter by download_user_count property"""
        return (
            select([func.count(distinct(PageView.user_id))])
            .where(PageView.object_id == self.id)
            .where(PageView.object_type == "post")
            .where(PageView.object_action == "download")
            .label("downloads_user_count")
        )

    def update_metadata_from_kp(self, kp: KnowledgePost):
        """
        Set field from KnowledgePost object to Post
        Args:
            kp: object
        """
        headers = kp.headers

        self.uuid = kp.uuid
        self.path = kp.path
        self.project = headers.get("project")
        self.repository = kp.repository_uri
        self.revision = kp.revision
        self.title = headers["title"]
        self.subtitle = headers.get("subtitle")
        self.tldr = headers["tldr"]
        self.tags = headers.get("tags", [])
        self.keywords = get_keywords(self)
        self.thumbnail = kp.thumbnail_uri

        self.created_at = headers["created_at"]
        self.updated_at = headers["updated_at"]
        if self.created_at > self.updated_at:
            self.updated_at = self.created_at

        self.status = kp.status

        self.private = 0
        # we do this check so that no header (None) and False are treated the same
        if headers.get("private", ""):
            self.private = 1
            self.groups = headers.get("allowed_groups", [])

        # handle new user creation separately,
        # to make sure we add all metadata for new users
        authors = [author.lower() for author in headers.get("authors", [])]
        for author in authors:
            get_or_create(db_session, author)
        self.authors = authors


class Email(db.Model):  # pylint:disable=too-few-public-methods
    """Email model"""

    __tablename__ = "emails"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    trigger_id = db.Column(db.Integer)
    trigger_type = db.Column(db.String(100))
    object_id = db.Column(db.Integer)
    object_type = db.Column(db.String(100))
    sent_at = db.Column(db.DateTime, default=func.now())
    subject = db.Column(db.Text)
    text = db.Column(db.Text)


@unique_constructor(
    lambda name: name, lambda query, name: query.filter(Group.name == name)
)
class Group(db.Model):
    """User group model"""

    __tablename__ = "groups"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), unique=True)

    _users = db.relationship(
        "User", secondary=assoc_group_user, backref="users", lazy="subquery"
    )

    def __str__(self):
        return f"Group: {self.name}"

    @hybrid_property
    def users(self) -> RelationshipProperty:
        """Group users"""
        return self._users

    @users.setter
    def users(self, user_objs):
        self._users = self._users + user_objs


class DownloadReason(db.Model):
    """Collect reasons for post downloads"""

    __tablename__ = "download_reasons"

    class ReasonEnum(Enum):
        """Reasons enum for reason field"""

        project = "project"
        research = "research"
        learning = "learning"
        other = "other"

    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=func.now())
    user_id = db.Column("user_id", db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User", lazy="joined")
    reason = db.Column(db.Enum(ReasonEnum), nullable=False)
    notes = db.Column(db.String(512), nullable=True)
    # nullable because we ask about reason before actual downloading
    download_id = db.Column(db.Integer, db.ForeignKey("pageviews.id"), nullable=True)
    download = db.relationship(
        "PageView",
        lazy="subquery",
        uselist=False,
        primaryjoin="and_(foreign(PageView.id)==DownloadReason.download_id, "
        "PageView.object_type=='post',"
        "PageView.object_action=='download')",
    )

    post = db.relationship(
        "Post",
        primaryjoin="DownloadReason.download_id == foreign(PageView.id)",
        secondary="join(PageView, Post, foreign(PageView.object_id) == foreign(Post.id))",
        secondaryjoin="remote(Post.id) == foreign(PageView.object_id)",
        viewonly=True,
    )

    def update_download_id(self, post_path: str) -> None:
        """Update download_id from the post"""
        self.download_id = (
            db_session.query(PageView)
            .filter(
                PageView.object_id
                == Post.query.filter(Post.path == post_path).first().id,
                PageView.object_type == "post",
                PageView.object_action == "download",
                PageView.user_id == self.user_id,
            )
            .order_by(PageView.id.desc())
            .first()
            .id
        )
        db_session.add(self)
        db_session.commit()
