# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa
"""
Encoding and Decoding for virtual file systems (knowledge posts).
Note that in the knowledge repo version,
"""
import logging
from typing import Any

logger = logging.getLogger(__name__)


def encode(data: Any) -> bytes:
    """
    Encode UTF-8
    """
    if isinstance(data, bytes):
        # UTF-8 data is already encoded
        return data
    elif not isinstance(data, str):
        data = str(data)

    try:
        data = data.encode("utf-8")
    except UnicodeError:
        logger.warning("An encoding error has occurred... continuing anyway.")
        data = data.encode("utf-8", errors="ignore")

    return data


def decode(data: str) -> str:
    """
    Decode UTF-8
    """
    try:
        data = data.decode("utf-8")
    except UnicodeError:
        logger.warning("An decoding error has occurred... continuing anyway.")
        data = data.decode("utf-8", errors="ignore")

    return data
