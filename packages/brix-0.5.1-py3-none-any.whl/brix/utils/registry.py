# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa
"""
Registring Meta Class.
This allows classes to be registered and imported by key.
"""

from abc import ABCMeta


class SubclassRegisteringABCMeta(ABCMeta):
    def __init__(cls, name, bases, dct):
        super().__init__(name, bases, dct)

        if not hasattr(cls, "_registry"):
            cls._registry = {}

        registry_keys = getattr(cls, "_registry_keys", [])
        if registry_keys:
            for key in registry_keys:
                if key in cls._registry and cls.__name__ != cls._registry[key].__name__:
                    raise RuntimeError(
                        "Class `{}` is trying to register key '{}', which is already registered for class `{}`.".format(
                            cls.__name__, key, cls._registry[key].__name__
                        )
                    )
                else:
                    cls._registry[key] = cls

    def _get_subclass_for(cls, key):
        return cls._registry[key]
