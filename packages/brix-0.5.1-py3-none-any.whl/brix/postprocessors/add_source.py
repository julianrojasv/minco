# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Postprocessor that adds the contents of non-ipynb source files
as collapsable fields to the markdown.
"""
import typing
from pathlib import Path
from typing import List, Union

import click

from brix.postprocessors.base import KnowledgePostProcessor
from brix.utils.encoding import decode

if typing.TYPE_CHECKING:
    from brix.post import KnowledgePost

COLLAPSIBLE_DIR = """
<details style="margin-left: {margin}px"><summary>📁 {dirname}</summary>
{contents}
</details>"""

COLLAPSIBLE_FILE = """
<details style="margin-left: {margin}px"><summary>{filename}</summary>
```{formatting}
{src}
```
</details>"""

COLLAPSIBLE_EMPTY = """
<details style="margin-left: {margin}px"><summary style="color: #999999">{filename} ({reason})</summary>
</details>"""

SUFFIX_TO_FORMATTING = {".py": "python", ".yml": "yaml", ".yaml": "yaml"}


class AddSourcePostprocessor(KnowledgePostProcessor):
    """
    ``AddSourcePostprocessor`` is a KnowledgePostProcessor which parses
    additional files in the knowledgepost's src/ folder and adds them
    to the Markdown in the form of a collabsable box.
    """

    _registry_keys = ["add_src"]

    def __init__(self, skip_suffixes: Union[str, List[str]] = None):
        """
        Creates new ``AddSourcePostprocessor``.

        Args:
            skip_suffixes: List of suffixes to ignore.
        """
        skip_suffixes = skip_suffixes or []
        if isinstance(skip_suffixes, str):
            skip_suffixes = [skip_suffixes]

        skip_suffixes = [
            "." + sfx if not sfx.startswith(".") else sfx for sfx in skip_suffixes
        ]

        self._suffixes_to_skip = skip_suffixes

    def process(self, kp: "KnowledgePost"):
        """
        Add source code to the bottom of the markdown file.
        """
        src_refs = sorted([ref for ref in kp.src_paths if not ref.endswith("ipynb")])

        md = kp.read()
        md += "\n\n--------------\n"
        md += "\n# Source Files\n"
        md += self._tree_view(src_refs, kp)
        kp.write(md)

    def _tree_view(self, suffix_refs, kp):
        def _get_sub_dirs(refs, directory):
            refs = [
                ref.replace(directory, "", 1)
                for ref in refs
                if ref.startswith(directory)
            ]
            return sorted(
                set(ref.split("/")[0] for ref in refs if len(ref.split("/")) > 1)
            )

        def _get_files(refs, directory):
            return [
                ref
                for ref in refs
                if ref.startswith(directory)
                and len(ref.replace(directory, "", 1).split("/")) == 1
            ]

        def _file_to_md(name, margin):
            filename = str(Path(name).name)
            suffix = Path(name).suffix
            if suffix in self._suffixes_to_skip:
                return COLLAPSIBLE_EMPTY.format(
                    filename=filename, reason="omitted", margin=margin
                )
            try:
                src = decode(kp.read_src(name[4:]))  # remove 'src/' prefix
            except Exception:  # pylint: disable=broad-except
                click.secho(
                    "Warning: Cannot read file {}, is it a text file?".format(name),
                    color="yellow",
                )
                src = "Binary file"
            if not src:
                return COLLAPSIBLE_EMPTY.format(
                    filename=filename, reason="empty", margin=margin
                )
            return COLLAPSIBLE_FILE.format(
                filename=filename,
                formatting=SUFFIX_TO_FORMATTING.get(suffix, ""),
                src=src,
                margin=margin,
            )

        def _dir_to_md(refs, directory, margin=20):
            md = "\n" + "\n".join(
                COLLAPSIBLE_DIR.format(
                    dirname=subdir,
                    contents=_dir_to_md(refs, directory + subdir + "/"),
                    margin=margin,
                )
                for subdir in _get_sub_dirs(refs, directory)
            )
            for name in _get_files(refs, directory):
                md += _file_to_md(name, margin=margin)
            return md + "\n"

        return _dir_to_md(suffix_refs, "src/", margin=0)
