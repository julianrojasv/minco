# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.


# pylint: skip-file
# flake8: noqa
from brix.post.header import HEADER_OPTIONAL_FIELD_TYPES, HEADER_REQUIRED_FIELD_TYPES

# modified from airbnb's knowledge repo
from .base import KnowledgePostProcessor


class FormatChecks(KnowledgePostProcessor):
    _registry_keys = ["format_checks"]

    def process(self, kp):
        headers = kp.headers
        for field, type_ in HEADER_REQUIRED_FIELD_TYPES:
            assert field in headers, "Required field `{}` missing from headers.".format(
                field
            )
            assert isinstance(
                headers[field], type_
            ), "Value for field `{}` is of type {}, and needs to be of type {}.".format(
                field, type(headers[field]), type_
            )
        for field, type_ in HEADER_OPTIONAL_FIELD_TYPES:
            if field in headers:
                assert isinstance(
                    headers[field], type_
                ), "Value for field `{}` is of type {}, and needs to be of type {}.".format(
                    field, type(headers[field]), type_
                )
