# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Postprocessor that adds a github URL for the post.
"""
import os
import typing

from brix.postprocessors.base import KnowledgePostProcessor

if typing.TYPE_CHECKING:
    from brix.post import KnowledgePost

TEMPLATE = """

## [View code on github]({url})

"""


class GithubUrlPostprocessor(KnowledgePostProcessor):
    """
    ``GithubUrlPostprocessor`` is a KnowledgePostProcessor which adds
    a link to github.
    """

    _registry_keys = ["add_github"]

    def __init__(self, base_url: str, branch: str = "master"):
        """
        Creates new ``GithubUrlPostprocessor``.

        Args:
            base_url: First part of the URL, e.g.
                      https://github.com/<org>/<repo>/
            branch: branch to use, e.g. `master`,
                    which would be translated to `/tree/master`
        """
        self._base_url = base_url
        self._branch = branch

    def process(self, kp: "KnowledgePost"):
        """
        Add link to the bottom of the markdown file.
        """
        path = kp.path
        full_url = os.path.join(self._base_url, "tree", self._branch, path)

        md = kp.read()
        md += "\n--------------\n"
        md += TEMPLATE.format(url=full_url)
        kp.write(md)
