# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa
import itertools
from collections import namedtuple
from datetime import datetime

# Define header fields
Header = namedtuple("Header", ("name", "type"))

HEADER_REQUIRED_FIELD_TYPES = [
    Header("title", str),
    Header("authors", list),
    Header("tldr", str),
    Header("created_at", datetime),
]

HEADER_OPTIONAL_FIELD_TYPES = [
    Header("subtitle", str),
    Header("tags", list),
    Header("path", str),
    Header("updated_at", datetime),
    Header("private", bool),
    Header("allowed_groups", list),
    Header("thumbnail", (int, str)),
]

HEADERS_ALL = {
    header.name: header
    for header in itertools.chain(
        HEADER_REQUIRED_FIELD_TYPES, HEADER_OPTIONAL_FIELD_TYPES
    )
}

HEADER_SAMPLE = """
---
title: "This is a Knowledge Post title, quoted so we can use special characters like ':'"
authors:
- sally_smarts@quantumblack.com
- wesly_wisdom@quantumblack.com
tags:
- knowledge
- example
created_at: 2016-06-29
updated_at: 2016-06-30
thumbnail: 2
tldr: |
    You can write any markdown you want here (the '|' character makes this an escaped section)

    * bullet
    * bullet

---
"""
