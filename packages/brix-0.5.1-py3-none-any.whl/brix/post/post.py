# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa
"""
Class representing a knowledge post
"""

import base64
import io
import logging
import os
import posixpath
import re
from datetime import date, datetime, time

import PIL.Image
import yaml

from brix.converters import KnowledgePostConverter
from brix.utils.encoding import decode, encode
from brix.utils.uuid_gen import generate_uuid

from .header import HEADER_REQUIRED_FIELD_TYPES, HEADER_SAMPLE
from .ref_cache import ReferenceCache

logger = logging.getLogger(__name__)


class KnowledgePost:
    """
    A "Knowledge Post" is a (virtual) folder in which there is a 'knowledge.md' file,
    and potentially an 'images' and/or 'src' folder. It is "virtual" in the sense
    that `KnowledgePost` objects store everything in memory, and use `KnowledgeRepository`
    object instances to interface with "physical" realisations of them. For example,
    in a GitKnowledgeRepository, the physical realisation is an actual folder; whereas
    in a database-backed KnowledgeRepository, on the virtual structure is maintained.
    """

    def __init__(self, path=None, revision=None, repository=None):
        self._path = path
        self.revision = revision
        self.repository = repository
        self._uuid = None
        self.__cache = ReferenceCache()

    @property
    def path(self):
        return self._path or self.headers.get("path")

    @path.setter
    def path(self, path):
        self._path = path

    @property
    def repository_uri(self):
        if self.repository is not None:
            return self.repository._kp_repository_uri(self.path)

    @property
    def uuid(self):
        if self._uuid is None:
            if self.repository is not None:
                self._uuid = self.repository._kp_uuid(
                    self.path
                )  # Use repository UUID (even if None)
            else:
                self._uuid = generate_uuid()
        return self._uuid

    @uuid.setter
    def uuid(self, uuid):
        self._uuid = uuid

    # ------------ Reference cache methods ------------------------------------------
    def _read_ref(self, ref):
        if (
            (ref not in self.__cache)
            and (self.repository is not None)
            and self.repository._kp_has_ref(self.path, ref)
        ):
            self.__cache[ref] = self.repository._kp_read_ref(self.path, ref)
        return self.__cache[ref]

    def _write_ref(self, ref, data):
        self.__cache[ref] = data

    def _drop_ref(self, ref):
        del self.__cache[ref]

    def _has_ref(self, ref):
        return (
            (ref in self.__cache)
            or (self.repository is not None)
            and self.repository._kp_has_ref(self.path, ref)
        )

    def _dir(self, parent=None):
        for ref in self.__cache.dir(parent=parent):
            if self.__cache[posixpath.join(parent or "", ref)] is not None:
                yield ref
        if self.repository is not None:
            for ref in self.repository._kp_dir(
                self.path, parent=parent, revision=self.revision
            ):
                if ref not in self.__cache:
                    yield ref

    # ---------- Knowledge Post Data Population -----------------------------

    def read(self, images=False, headers=True, body=True):
        if not (body or headers):
            md = ""
        else:
            md = decode(self._read_ref("knowledge.md"))
            mtch = re.match("^---\n[\\s\\S]+?---\n", md)
            if not mtch:
                raise ValueError(
                    "YAML header is missing. "
                    "Please ensure that the top of your post has a header of the following form:\n"
                    + HEADER_SAMPLE
                )
            if not headers:
                md = re.sub("^---\n[\\s\\S]+?---\n", "", md, count=1)
            if not body:
                md = mtch.group(0)
        if images:
            return md, self.read_images()
        return md

    @property
    def image_paths(self):
        return [
            "images/{}".format(image_name) for image_name in self._dir(parent="images")
        ]

    def read_image(self, name):
        return self._read_ref("images/" + name)

    def read_images(self):
        image_data = {}
        for image_path in self.image_paths:
            image_data[image_path] = self._read_ref(image_path)
        return image_data

    @property
    def src_paths(self):
        srcs = ["src/{}".format(src_name) for src_name in self._dir(parent="src")]
        return srcs

    def read_src(self, ref):
        return self._read_ref("src/" + ref)

    def write(self, md, headers=None, images=None):
        images = images or {}
        md = md.strip()

        if not headers:
            header = re.match(r"---(.*?)---", md, re.DOTALL)
            if not header:
                raise ValueError("The header is missing from the top of the post.")
            headers = self._get_headers_from_yaml(header.group(0))
        headers = self._verify_headers(headers)

        md = re.sub(r"^---\n[\s\S]+?---\n", "", md, count=1)

        md = (
            "---\n" + yaml.safe_dump(headers, default_flow_style=False) + "---\n\n" + md
        )

        self._write_ref("knowledge.md", encode(md))

        for image, data in list(images.items()):
            self._write_ref("images/" + image, data)

    def write_image(self, name, data):
        self._write_ref("images/" + name, data)

    def write_images(self, image_data=None):
        image_data = image_data or {}
        for name, data in image_data.items():
            self.write_image(name, data)

    def write_src(self, name, data):
        self._write_ref("src/" + name, encode(data))

    def add_srcfile(self, filename, name=None):
        if not name:
            name = os.path.basename(filename)
        with open(filename, "rb") as f:
            self.write_src(name, f.read())

    # ------------- Knowledge Post Format ----------------------------------

    def _get_headers_from_yaml(self, yaml_str):
        try:
            if not yaml_str.strip().startswith("---"):
                raise StopIteration()
            return next(yaml.safe_load_all(yaml_str))
        except yaml.YAMLError as err:
            logger.info(
                "YAML header is incorrectly formatted or missing. The following "
                "information may be useful:\n%s\n",
                str(err),
            )
        except StopIteration:
            logger.info("YAML header is missing!")
        return {}

    def _verify_headers(self, headers):
        if not isinstance(headers, dict):
            raise RuntimeError()
        missing_required_headers = set(
            h.name for h in HEADER_REQUIRED_FIELD_TYPES
        ).difference(headers)

        if missing_required_headers:
            raise RuntimeError(
                "Knowledge post is missing required headers {}. "
                "Please add headers manually to the "
                "post source file.".format(missing_required_headers)
            )

        for key, value in list(headers.items()):
            if value is None:
                del headers[key]

        email_regexp = r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$"
        for idx, author in enumerate(headers["authors"]):
            if not re.fullmatch(email_regexp, author):
                raise RuntimeError(
                    "{} is an invalid email. Please fix it at the top of post.ipynb".format(
                        author
                    )
                )
            headers["authors"][idx] = author.lower().strip()

        if "tags" not in headers or not headers["tags"]:
            headers["tags"] = []

        updated_at = headers["updated_at"]

        if not updated_at:
            raise RuntimeError(
                "Missed updated_at headers. Please fix it at the top of post.ipynb"
            )

        if not isinstance(updated_at, date):
            try:
                updated_at = datetime.strptime(updated_at, "%Y-%m-%d")
            except ValueError as exception:
                raise RuntimeError(
                    "{}. Please fix it at the top of post.ipynb".format(str(exception))
                )

        if updated_at.year < 2019:
            raise RuntimeError(
                "{} should be not less than 2019. "
                "Please fix it at the top of post.ipynb".format(updated_at.year)
            )

        headers["updated_at"] = updated_at

        return headers

    @property
    def headers(self):
        headers = self._get_headers_from_yaml(self.read(body=False))
        if not headers:
            raise ValueError(
                "YAML header is missing. Please ensure that the top of your post has a header of the following form:\n"
                + HEADER_SAMPLE
            )
        for key, value in headers.copy().items():
            if isinstance(value, date):
                headers[key] = datetime.combine(value, time(0))
            if key == "tags" and isinstance(value, list):
                headers[key] = [str(v) for v in value]
        return headers

    @headers.setter
    def headers(self, headers):
        self.write(self.read(headers=False), headers=headers)

    def update_headers(self, **headers):
        curr_headers = self.headers
        for header, value in headers.items():
            if value is None:
                if header in curr_headers:
                    curr_headers.pop(header)
            else:
                curr_headers[header] = value
        self.headers = curr_headers

    @property
    def thumbnail_uri(self):
        thumbnail = self.headers.get("thumbnail")

        if not thumbnail or not isinstance(thumbnail, str):
            return None

        if ":" not in thumbnail:  # if thumbnail points to a local reference
            if not self._has_ref(thumbnail):
                return None

            data_in = io.BytesIO(self._read_ref(thumbnail))
            data_out = io.BytesIO()

            try:  # Attempt to generate 125x125 png thumbnail from resource
                img = PIL.Image.open(data_in)

                # 125x125 is approximately the maximum size we can guarantee
                # will fit in the thumbnail uri data field, with max characters
                # of 65535 for a PNG with 32 bits per pixel
                img.thumbnail((125, 125))

                data_out = io.BytesIO()
                img.save(data_out, "png")
                data_out.seek(0)
                thumbnail_data = data_out.read()

                data = base64.b64encode(thumbnail_data)
                thumbnail = "data:{};base64,".format("image/png") + data.decode("utf-8")
            except Exception as e:
                logger.warning("Thumbnail generation failed for %s: %s.", self.path, e)
                return None
            finally:
                data_in.close()
                data_out.close()

        return thumbnail

    def is_valid(self):
        from brix.postprocessors.format_checks import FormatChecks

        if not self._has_ref("knowledge.md"):
            return False
        try:
            FormatChecks().process(self)
        except:
            return False
        return True

    @property
    def status(self):
        if self.repository is not None:
            return self.repository._kp_status(self.path, revision=self.revision)

    @property
    def is_published(self):
        return self.status == self.repository.PostStatus.PUBLISHED

    @property
    def is_accepted(self):
        return self.status in [
            self.repository.PostStatus.UNPUBLISHED,
            self.repository.PostStatus.PUBLISHED,
        ]

    @property
    def web_uri(self):
        if self.repository is not None:
            return self.repository._kp_web_uri(self.path)

    # Conversion/Import/Export methods
    @classmethod
    def from_file(cls, filename, src_paths=[], fmt=None, postprocessors=None, **opts):
        kp = KnowledgePostConverter.for_file(
            cls(), filename, fmt=fmt, postprocessors=postprocessors
        ).from_file(filename, **opts)
        if src_paths:
            for src_path in src_paths:
                kp.add_srcfile(src_path)
        return kp

    def to_file(self, filename, fmt=None, **opts):
        return KnowledgePostConverter.for_file(self, filename, fmt=fmt).to_file(
            filename, **opts
        )

    def to_string(self, fmt, **opts):
        return KnowledgePostConverter.for_format(self, fmt).to_string(**opts)
