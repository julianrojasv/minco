# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""A Kedro project context for use within the {{ cookiecutter.block_name }} block"""

from pathlib import Path
from typing import Dict

from kedro.framework.context import KedroContext
from kedro.pipeline import Pipeline

from .pipeline import create_pipelines


class ProjectContext(KedroContext):
    """A ProjectContext for use within a post"""

    project_name = "{{ cookiecutter.block_dir }}"
    project_version = "{{  cookiecutter.kedro_version }}"

    def _get_pipelines(self) -> Dict[str, Pipeline]:
        return create_pipelines()

    def _setup_logging(self):
        pass


def get_kedro_context() -> ProjectContext:
    """Provides kedro context for the block.
    Do not copy this over to a real kedro project.
    """
    project_root = Path(__file__).parent.parent
    # see https://github.com/quantumblacklabs/private-kedro/issues/229
    return ProjectContext(project_root, env="base")
