# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""{{ cookiecutter.pipeline_name }} pipeline"""

from kedro.pipeline import Pipeline, node

from .nodes import say_hello


def create_pipeline(**kwargs) -> Pipeline:  # pylint:disable=unused-argument
    """Create the {{ cookiecutter.block_name }} pipeline.

    Args:
        kwargs: Ignore any additional arguments added in the future.

    Returns:
        A pipeline object
    """

    return Pipeline([node(say_hello, "params:name", "greeting", name="say_hello")])
