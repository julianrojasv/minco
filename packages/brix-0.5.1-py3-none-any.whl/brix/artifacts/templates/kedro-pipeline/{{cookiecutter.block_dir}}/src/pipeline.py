# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""{{ cookiecutter.block_dir }} pipelines"""

from typing import Dict

from kedro.pipeline import Pipeline

from .pipelines import {{cookiecutter.pipeline_name}}


# pylint: disable=unused-argument
def create_pipelines(**kwargs,) -> Dict[str, Pipeline]:
    """Create the {{ cookiecutter.block_dir }} pipeline.

    Args:
        kwargs: Ignore any additional arguments added in the future.

    Returns:
        A mapping from a pipeline name to a ``Pipeline`` object.
    """

    {{cookiecutter.pipeline_name}}_pipeline = {{cookiecutter.pipeline_name}}.create_pipeline()

    return {
        "{{cookiecutter.pipeline_name}}": {{cookiecutter.pipeline_name}}_pipeline,
        "__default__": {{cookiecutter.pipeline_name}}_pipeline,
    }
