# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Functions to collect the known artifacts
"""
from pathlib import Path
from typing import Dict

import brix

BRIX_PATH = Path(brix.__file__).parent
TEMPLATE_PATH = BRIX_PATH.joinpath("artifacts/templates")


def collect_templates() -> Dict[str, Path]:
    """
    Returns dict of available templates with paths and keys.
    """
    templates = [
        temp
        for temp in TEMPLATE_PATH.glob("*")
        if temp.is_dir() and not temp.name.startswith(".")
    ]
    return {temp.stem: temp for temp in templates}
