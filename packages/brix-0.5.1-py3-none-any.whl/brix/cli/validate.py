# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Validation functions for repos and posts
"""
from pathlib import Path
from typing import Union


def validate_post(path: Union[str, Path], raise_: bool = False) -> bool:
    """
    validate that a folder can be converted to a knowledge post
    """
    if not isinstance(path, Path):
        path = Path(path)

    post_nb = path / "post.ipynb"
    post_uuid = path / "UUID"

    is_post = (
        path.exists() and path.is_dir() and post_nb.exists() and post_uuid.exists()
    )

    if not is_post and raise_:
        raise ValueError(
            "`{}` can not be converted to a knowledge post.".format(str(path))
        )

    return is_post


def validate_repo(path: Union[str, Path], raise_: bool = False) -> bool:
    """
    validate that a folder is a knowledge repo
    """
    if not isinstance(path, Path):
        path = Path(path)

    config_file = path / "rcps_config.yml"

    is_repo = path.exists() and path.is_dir() and config_file.exists()

    if not is_repo and raise_:
        raise ValueError(
            "`{}` does not seem to be a valid knowledge repo.".format(str(path))
        )

    return is_repo
