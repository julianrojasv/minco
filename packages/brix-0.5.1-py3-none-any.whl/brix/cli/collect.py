# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Collect block
"""
import re
from io import StringIO
from itertools import chain
from pathlib import Path
from typing import Dict, List, Set, Union

import git
import yaml
from click import secho


def collect_block_paths(start_dir: Union[str, Path]) -> List[Path]:
    """
    Return all block folders below a parent folder

    Args:
        start_dir: The folder in which to look for brix

    Returns:
        A list of all block paths
    """
    rcp_paths = []
    stack = [Path(start_dir)]
    while stack:
        curr = stack.pop()
        elements = list(curr.glob("*"))
        if curr.joinpath("post.ipynb") in elements:
            rcp_paths.append(curr)
            continue

        sub_dirs = [
            elem
            for elem in elements
            if elem.is_dir()
            and elem.resolve().parent == curr  # no links
            and not elem.name.startswith(".")  # not hidden
        ]
        stack.extend(sub_dirs)

    return rcp_paths


def collect_categories(start_dir: Union[str, Path]) -> List[Path]:
    """
    Return the paths of all categories below a parent folder

    Args:
        start_dir: The folder in which to look for categories

    Returns:
        A list of paths representing all existing categories
    """
    category_paths = set()
    stack = [Path(start_dir)]
    while stack:
        curr = stack.pop()
        elements = list(curr.glob("*"))
        if curr.joinpath("post.ipynb") in elements:
            category_paths.add(curr.parent)
            continue

        sub_dirs = [
            elem
            for elem in elements
            if elem.is_dir()
            and elem.resolve().parent == curr  # no links
            and not elem.name.startswith(".")  # not hidden
        ]
        if not sub_dirs:
            category_paths.add(curr)

        stack.extend(sub_dirs)

    return list(sorted(category_paths))


def collect_tags(start_dir: str) -> Set[str]:
    """
    Get all tags of all post

    Args:
        start_dir: The folder in which to look for brix and their tags

    Returns:
        A set containing all tags of all brix
    """
    recipes = collect_block_paths(start_dir)
    tags = set()
    for recipe in recipes:
        with open(str(recipe / "post.ipynb")) as post:
            content = post.read()
        try:
            tags_regex = r"\"tags:.+?:"
            tags_json = re.search(tags_regex, content, re.DOTALL).group()
            tags_str = (
                tags_json.replace('\\n",', "").replace('"', "").rsplit("\n", 1)[0]
            )
            tags.update(yaml.safe_load(StringIO(tags_str))["tags"])
        except Exception:  # pylint: disable=broad-except
            secho("Could not get tags of {}".format(recipe), color="yellow")
    return tags


def collect_altered_block_paths(start_dir: Union[str, Path]) -> List[Path]:
    """
    Return all knowledge post folders below a parent folder that have been altered.

    Args:
        start_dir: The folder in which to look for brix

    Returns:
        A list of all altered brix' paths
    """
    all_recipes = collect_block_paths(start_dir)
    repo = _get_git_repo(start_dir)
    root = Path(repo.common_dir).parent
    changed_files = [
        root / f for f in repo.git.diff("--name-only", "develop").split("\n")
    ]

    changed_files_parents = set(chain.from_iterable(f.parents for f in changed_files))
    changed_posts = list(set(all_recipes) & changed_files_parents)
    return changed_posts


def load_config(start_dir: Union[str, Path], filename: str = "rcps_config.yml") -> Dict:
    """
    Loads and returns configuration file.

    Args:
        start_dir: The directory in which to look for the configuration file
        filename: The name of the config file

    Returns:
        The config as a dictionary

    Raises:
        FileNotFoundError: If the file does not exist.
    """
    start_dir = Path(start_dir)
    config_file = start_dir / filename
    if not config_file.exists():
        raise FileNotFoundError("Could not read {}.".format(str(config_file)))
    with config_file.open("r") as io:
        config = yaml.safe_load(io)

    return config


def _get_git_repo(start_dir: Path) -> git.Repo:
    """
    Search for git repo in parent folders
    """
    for parent in [start_dir, *start_dir.parents]:
        if (parent / ".git").is_dir():
            return git.Repo(parent)

    raise FileNotFoundError("Could not find git repository")
