# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Brix CLI
"""
# pylint: disable=too-many-lines
# some imports are lazily loaded in the functions in order to
# make the CLI more reactive
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import webbrowser
from datetime import datetime
from functools import partial
from math import ceil
from pathlib import Path
from textwrap import fill
from typing import Any, Callable, Dict, List, Tuple, Union

import click
from click import ClickException, style
from kedro import __version__ as kedro_version
from tqdm.utils import _environ_cols_wrapper

from brix import __version__ as version
from brix.artifacts import collect_templates
from brix.cli.collect import (
    collect_altered_block_paths,
    collect_block_paths,
    collect_categories,
    collect_tags,
    load_config,
)
from brix.cli.easteregg import print_gem
from brix.utils.uuid_gen import generate_uuid

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
_VERBOSE = True
TEMPLATES = collect_templates()  # type:dict
EXCLUDED_DIRECTORIES = {".", "docker", "coverage"}
DEPLOY_AUTH_PROVIDER = "okta"
ANONYMOUS_APP_SETTINGS = {
    "POLICY_ANONYMOUS_VIEW_INDEX": True,
    "POLICY_ANONYMOUS_VIEW_POST": True,
    "POLICY_ANONYMOUS_VIEW_STATS": True,
    "POLICY_ANONYMOUS_DOWNLOADS": True,
}

LOGO = r"""____________________._______  ___
\______   \______   \   \   \/  /
 |    |  _/|       _/   |\     /
 |    |   \|    |   \   |/     \
 |______  /|____|_  /___/___/\  \
        \/        \/          \_/
v{}""".format(
    version
)


def _search_for_repo_root() -> Path:
    """
    Search upwards for the repo path, if found return it, else return cwd
    """
    for possible_root in [Path.cwd(), *Path.cwd().parents]:
        if (possible_root / "rcps_config.yml").is_file():
            return possible_root
    return Path.cwd()


def _check_repo(ctx, param, val) -> Path:  # pylint: disable=unused-argument
    """
    Check that a repo argument is valid. Returns a Path object.
    """
    repo_path = Path(val)
    if not (repo_path / "rcps_config.yml").exists():
        raise click.BadParameter(
            "\n"
            + style(
                fill(
                    "The directory {} does not contain "
                    "a `rcps_config.yml` file.".format(val)
                ),
                fg="red",
            )
            + style(
                "\nClone the QB_knowledge_repo if you have not already done so:",
                fg="yellow",
            )
            + style(
                "\ngit clone git@github.com:quantumblack/QB_knowledge_repo.git",
                fg="bright_yellow",
                bold=True,
            )
        )
    return repo_path


def _search_posts(ctx, param, val) -> List[Path]:  # pylint: disable=unused-argument
    """
    Collects posts. If no value is specified, collect all changed files from CWD onwards.
    If values are specified, for each one, if it is a path to a post.ipynb file,
    return the directory containing that file. If it is a directory with a post.ipynb,
    then return the directory, otherwise collect all changed posts within that dir.
    """
    if not val:
        return _get_default_posts()

    post_paths = []
    for post_path in val:
        post_path = Path(post_path)
        if post_path.is_file() and post_path.name == "post.ipynb":
            post_paths.append(post_path.parent)
        if post_path.is_dir() and (post_path / "post.ipynb").is_file():
            post_paths.append(post_path)
        else:
            post_paths.extend(_get_default_posts(post_path))
    return post_paths


def _get_default_posts(start_dir: Path = None) -> List[Path]:
    current_dir = start_dir or Path.cwd()
    if (current_dir / "post.ipynb").is_file():
        return [current_dir]
    return collect_altered_block_paths(current_dir)


repo_option = click.option(  # pylint:disable=invalid-name
    "--repo",
    help="The repository's base folder",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, resolve_path=True),
    required=True,
    default=_search_for_repo_root,
    callback=_check_repo,
)

post_argument = click.argument(  # pylint:disable=invalid-name
    "posts",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, resolve_path=True),
    nargs=-1,
    callback=_search_posts,
)


def _get_app(repo, **kwargs):
    # Todo delete after QB_knowledge_repo will be update
    from brix.app.deploy import get_app_builder

    config = load_config(repo)
    repo_uri = config["repo_uri"]  # type:str
    return get_app_builder(repo_uri, config=config, **kwargs)()


@click.group(name="Brix CLI", context_settings=CONTEXT_SETTINGS)
@click.version_option(version, "--version", "-V", help="Show version and exit")
@click.option(
    "--verbose", "-v", is_flag=True, help="See extensive logging and error stack traces"
)
def cli(verbose):
    """
    Brix - a code sharing platform.
    """
    global _VERBOSE  # pylint: disable=global-statement
    _VERBOSE = verbose


@cli.command(hidden=True)
def gems():
    """ Easteregg """
    print_gem()


@cli.command()
def list_templates():
    """
    List all available templates.
    """
    items = list(TEMPLATES.keys())
    click.echo("Available templates:")
    for i, item in enumerate(items, 1):
        click.echo("{}) {}".format(i, item))


@cli.command()
@repo_option
@click.option("--full", is_flag=True, help="Return full path.")
def list_posts(repo, full):
    """
    Finds and lists all blocks in a folder.
    """
    rcps_paths = sorted(collect_block_paths(repo))
    if not full:
        rcps_paths = [path.relative_to(repo) for path in rcps_paths]
    for path in rcps_paths:
        click.secho(str(path))


@cli.command(name="generate-uuid")
def generate_uuid_():
    """
    Generate a unique ID for a block.
    """
    click.secho(generate_uuid())


@cli.command()
@repo_option
def new(repo: str):
    """
    Create a new block from a given template.
    """
    from cookiecutter.main import cookiecutter

    width = _environ_cols_wrapper()(sys.stdout) or 0
    click.secho("—" * width, fg="bright_blue")
    click.secho(LOGO, fg="magenta")
    click.echo(
        "A code sharing platform, powered by " + style("Alchemy", fg="blue", bold=True)
    )
    click.secho("—" * width, fg="bright_blue")
    click.secho("Create a new post", bold=True)

    try:
        config = _get_config_from_prompts(repo)
        config.setdefault("brix_version", version)
        config.setdefault("block_uuid", generate_uuid())
        config.setdefault("created_at", str(datetime.now())[:10])

        template = config["template"]
        if template == "kedro-pipeline":
            config["kedro_version"] = kedro_version
        template_path = template if isinstance(template, Path) else TEMPLATES[template]
        out = config["output_dir"]
        config["block_dir"] = config["block_name"]
        config["block_name"] = config["block_name"].replace("_", " ").capitalize()
        created_at = Path(
            cookiecutter(
                str(template_path),
                output_dir=out,
                no_input=True,
                extra_context=config,
                overwrite_if_exists=True,
            )
        )
        _clean_pycache(created_at)
        _print_success_message(created_at)
    except click.exceptions.Abort:  # pragma: no cover
        _handle_exception("User interrupt.")
    # we don't want the user to see a stack trace on the cli
    except Exception:  # pylint: disable=broad-except
        _handle_exception("Failed to generate project.")


def _clean_pycache(project_path):
    # Since template is part of the Kedro package __pycache__ is generated.
    # This method recursively cleans all __pycache__ folders.
    to_delete = [
        filename.resolve()
        for filename in project_path.rglob("**/*")
        if str(filename).endswith("__pycache__")
    ]

    for file in to_delete:  # pragma: no cover
        shutil.rmtree(str(file))


def _get_config_from_prompts(repo_path) -> Dict:
    """Ask user to provide necessary inputs.

    Returns:
        Resulting config dictionary.
    """
    categories, categories_str = _get_categories(repo_path)
    output_dir_prompt = _get_prompt_text(
        "CATEGORY",
        "Choose the main category of your block. You'll have the opportunity to add "
        "more tags later.",
        categories_str,
        "Choose a number",
    )
    output_dir = _get_user_input(
        output_dir_prompt,
        validate_funcs=partial(_validate_output_dir, categories=categories),
    )

    block_name_prompt = _get_prompt_text("BLOCK NAME", "Choose a name for your block.")
    block_name = _get_user_input(
        block_name_prompt,
        "my_first_draft",
        partial(_validate_block_name, output_dir=output_dir),
    )

    authors_prompt = _get_prompt_text(
        "AUTHORS", "A comma separated list of authors' emails."
    )
    authors = _get_user_input(authors_prompt, _get_default_author(), _validate_authors)

    existing_tags = list(
        sorted(
            set(
                re.sub(r"[^a-zA-Z0-9_]+", "_", tag.lower()).strip("_").strip()
                for tag in collect_tags(repo_path)
            )
        )
    )
    tags_prompt = _get_prompt_text(
        "TAGS",
        "Here are the existing tags - feel free to create new ones.",
        style(_to_str_table(existing_tags, col_width=28, columns=3), fg="cyan"),
        "Comma separated list of tags, lowercase_underscore",
    )
    tags = _get_user_input(tags_prompt, default="", validate_funcs=_validate_tags)

    templates = sorted(TEMPLATES.keys())
    templates_str = "    ".join(
        "[{}] {}".format(idx + 1, template) for idx, template in enumerate(templates)
    )
    template_prompt = _get_prompt_text(
        "TEMPLATE",
        "Which template would you like to use?\nPlease select a number, below or enter a valid template path.",
        style(templates_str, fg="cyan"),
    )
    template = _get_user_input(
        template_prompt, "default", partial(_validate_template, templates=templates)
    )

    config = {
        "block_name": block_name,
        "authors": authors,
        "tags": tags,
        "template": template,
        "output_dir": output_dir,
    }

    pipeline_name_prompt = _get_prompt_text(
        "PIPELINE_NAME", "Choose a name for your pipeline."
    )

    if template == "kedro-pipeline":
        pipeline_name = _get_user_input(
            pipeline_name_prompt, block_name, _validate_block_name_pattern
        )
        config["pipeline_name"] = pipeline_name

    return config


def _get_prompt_text(title, *text):
    title = title.strip()
    width = _environ_cols_wrapper()(sys.stdout) or 0
    title = click.style(title + "\n" + "=" * (len(title) + 1), bold=True)
    title = style("—" * width, fg="bright_blue") + "\n" + title
    prompt_text = [title] + list(text)
    return "\n".join(str(x).strip() for x in prompt_text) + "\n"


def _get_user_input(
    text: str,
    default: Any = None,
    validate_funcs: Union[Callable, List[Callable]] = None,
) -> Any:
    """Get user input and validate it.

    Args:
        text: Text to display in command line prompt.
        default: Default value for the input.
        validate_funcs: List of functions to apply to user input.
            Value is overridden by function output if the latter is
            not None.

    Returns:
        Processed user value.
    """
    if callable(validate_funcs):
        validate_funcs = [validate_funcs]
    else:
        validate_funcs = validate_funcs or []
    looping = False
    while True:
        try:
            value = click.prompt(looping or text, default=default or "").strip()
            looping = "Try again"
            for _func in validate_funcs:
                output = _func(value)
                value = output or value
        except BrixCliError as exc:
            click.secho(str(exc), fg="red", err=True)
        else:
            break
    return value


def _get_categories(repo_path: str) -> Tuple[List[str], str]:
    """
    Get the brix categories based on the folder structure, relative to the repo_path

    Args:
        repo_path: The root of the knowledge repo

    Returns:
        A tuple where the first element is a list of all categories, and the second
        a string table of numbered categories
    """
    categories = (
        str(cat.relative_to(repo_path)) for cat in collect_categories(repo_path)
    )
    categories = [cat for cat in categories if cat not in EXCLUDED_DIRECTORIES]
    numbered = ["[{}] {}".format(idx + 1, cat) for idx, cat in enumerate(categories)]
    return categories, _to_str_table(numbered, col_width=35, columns=2)


def _to_str_table(arr, col_width, columns):
    rows = ceil(len(arr) / columns)

    def _get_row(idx):
        return "  ".join(
            arr[idx + j * rows].ljust(col_width) if idx + j * rows < len(arr) else ""
            for j in range(columns)
        )

    return style("\n".join(_get_row(idx) for idx in range(rows)), fg="cyan")


def _get_default_author():
    try:
        return (
            subprocess.run(
                ["git", "config", "user.email"], check=True, capture_output=True
            )
            .stdout.strip()
            .decode()
            .lower()
            .strip()
        )
    except Exception:  # pylint: disable=broad-except
        return None


def _validate_output_dir(output_dir, categories):
    err_msg = "Invalid number. Please choose a number between 1-{}.".format(
        len(categories)
    )
    try:
        idx = int(output_dir) - 1
        if idx < 0 or idx >= len(categories):
            raise BrixCliError(err_msg)
        return categories[idx]
    except ValueError:
        pass

    if output_dir not in categories:
        raise BrixCliError(
            "Category {} does not exist. Please choose one of the options above.".format(
                output_dir
            )
        )
    return output_dir


def _validate_block_name_pattern(name):
    name_pattern = r"^[a-z_]{3,30}$"
    if re.match(name_pattern, name) is None:
        raise BrixCliError("Invalid name. Must conform to `{}`.".format(name_pattern))


def _validate_block_name(name, output_dir):
    name = name.strip().lower()
    _validate_block_name_pattern(name)

    dst_dir = Path(output_dir) / name
    if dst_dir.exists():
        click.confirm(
            style(
                "WARNING: Folder `{}` exists. Overwrite?".format(dst_dir), fg="yellow"
            ),
            abort=True,
        )
        if os.path.isdir(dst_dir):
            shutil.rmtree(dst_dir)
        else:
            os.remove(dst_dir)
    return name


def _validate_authors(authors):
    if not authors:
        return "[]"
    authors = [author.strip() for author in authors.split(",")]
    email_regexp = r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$"
    for author in authors:
        if not re.match(email_regexp, author):
            raise BrixCliError("{} is not a valid email address".format(author))
    return "[" + ", ".join(author.lower().strip() for author in authors) + "]"


def _validate_tags(tags):
    tags = {tag.strip() for tag in tags.split(",")}
    tags = {re.sub("[^0-9a-zA-Z]+", "_", tag).strip("_").lower() for tag in tags}
    return "[" + ", ".join(sorted(tags)) + "]"


def _validate_template(template, templates) -> Union[str, Path]:
    """
    A valid template input can be one of three things (in order of evaluation):
        1) a name indicating the desired built-in template
        2) a number indicating the desired built-in template
        3) a valid path
    """
    # by name
    if template in templates:
        return template

    # by number
    try:
        idx = int(template) - 1
        if idx < 0 or idx >= len(templates):
            raise BrixCliError(
                "Invalid number. Please choose a number between 1-{}.".format(
                    len(templates)
                )
            )
        return templates[idx]
    except ValueError:
        pass

    # by path
    template_path = Path(template)
    if template_path.exists():
        if not template_path.joinpath("cookiecutter.json").exists():
            raise BrixCliError(
                "`{}` does not appear to be a valid cookiecutter template.".format(
                    template_path
                )
            )
        return template_path

    raise BrixCliError(
        "Template `{}` does not exist. Please choose one of the options above or a valid path.".format(
            template
        )
    )


@cli.command(name="compile")
@repo_option
@click.option("--yes", "-y", is_flag=True, help="Create a new repo without querying.")
@click.option(
    "--raise",
    "raise_",
    is_flag=True,
    help="Raise exception if a block can't be added.",
)
def compile_(repo, yes, raise_):
    """
    Collect all blocks and update the repo.
    """
    from brix.post import KnowledgePost
    from brix.repo import KnowledgeRepository

    config = load_config(repo)
    repo_uri = config["repo_uri"]  # type:str
    repo_config = config.get("repo_config", {})  # type: dict

    rcps_paths = collect_block_paths(repo)
    if not rcps_paths:
        raise click.UsageError(
            "Could not find any post paths in folder `{}`.".format(repo)
        )
    click.secho("{} block found.".format(len(rcps_paths)))

    if not KnowledgeRepository.exists(repo_uri):
        if not yes:
            click.confirm(
                "Did not find a repository at `{}`. Do you want to create it?".format(
                    repo_uri
                ),
                abort=True,
            )
        click.secho("Creating a clean repo at `{}`...".format(repo_uri))
    else:
        click.secho("Found existing repo at `{}`. Resetting...".format(repo_uri))

    kr = KnowledgeRepository.create_for_uri(
        uri=str(repo_uri), config=repo_config
    )  # type: KnowledgeRepository

    # keep track of duplicate UUIDs
    uuids_seen = {}

    for recipe in rcps_paths:
        rel_path = str(recipe.relative_to(repo))
        click.secho("Adding {} ...".format(rel_path))

        try:
            kp = KnowledgePost.from_file(str(recipe), fmt="block")
            kp.path = rel_path
            curr_uuid = kp.uuid
            if curr_uuid is None:
                raise RuntimeError("UUID is None.")
            if curr_uuid in uuids_seen:
                if raise_:
                    raise RuntimeError(
                        "Duplicate UUID found for `{}` and `{}`.".format(
                            rel_path, uuids_seen[curr_uuid]
                        )
                    )
                click.secho(
                    (
                        "Duplicate UUID found for `{first}` and `{second}`. "
                        "Generating new ID for `{second}`."
                    ).format(first=uuids_seen[curr_uuid], second=rel_path),
                    fg="yellow",
                )
                kp.uuid = generate_uuid()
            uuids_seen[kp.uuid] = rel_path

            kr.add(kp, path=rel_path, update=True)

            # TODO: remove statuses?
            kr.submit(path=rel_path)
            kr.accept(path=rel_path)
            kr.publish(path=rel_path)

        except Exception as exc:  # pylint:disable=broad-except
            click.secho('Could not add `{}`: "{}"'.format(rel_path, str(exc)), fg="red")
            if raise_:
                raise exc

    click.secho("Success.", fg="green")


@cli.command()
@repo_option
@click.option(
    "--port",
    "-p",
    default=8000,
    help="Specify the port on which to run the web server.",
)
@click.option("--dburi", help="The SQLAlchemy database uri.")
@click.option("--host", "-h", help="host address", default="127.0.0.1")
@click.option("--nobrowser", is_flag=True, help="Do not start a web browser")
@click.option(
    "--compile",
    "compile_first",
    is_flag=True,
    help="Compile repository if it is not found.",
)
@click.pass_context
def show(ctx, repo, port, dburi, host, nobrowser, compile_first):
    """
    Run the app.
    """
    from brix.app.deploy import KnowledgeDeployer, get_app_builder
    from brix.repo import KnowledgeRepository

    config = load_config(repo)
    repo_uri = config["repo_uri"]  # type:str

    if compile_first:
        ctx.invoke(compile_, repo=repo, yes=True, raise_=False)

    if not KnowledgeRepository.exists(repo_uri):
        raise click.UsageError(
            "Did not find a repository at `{}`. "
            "Use `brix compile` or the `--compile` option to create it".format(repo_uri)
        )

    app_builder = get_app_builder(
        repo_uri,
        debug=False,
        db_uri=dburi,
        config=None,
        INDEXING_ENABLED=True,
        **ANONYMOUS_APP_SETTINGS
    )

    if not nobrowser:
        url = "http://{}:{}".format(host, port)
        threading.Timer(1.25, lambda: webbrowser.open(url)).start()

    KnowledgeDeployer.using("flask")(app_builder, host=host, port=port).run(
        use_reloader=False
    )


@cli.command()
@repo_option
@click.option(
    "--port",
    "-p",
    default=8000,
    help="Specify the port on which to run the web server.",
)
@click.option("--dburi", help="The SQLAlchemy database uri.")
@click.option("--host", "-h", default="127.0.0.1")
@click.option("--nobrowser", is_flag=True, help="Do not start a web browser")
@post_argument  # pylint: disable=too-many-locals
def preview(repo, port, dburi, host, posts, nobrowser):
    """
    Compile and preview a single block.
    """
    from brix.app.deploy import KnowledgeDeployer, get_app_builder
    from brix.post import KnowledgePost
    from brix.repo import KnowledgeRepository

    if len(posts) != 1:
        raise click.UsageError("Please specify a single block to preview.")
    post = posts[0]

    config = load_config(repo)
    repo_config = config.get("repo_config", {})  # type: dict

    with tempfile.TemporaryDirectory() as tmpdirname:
        repo_uri = "file://{}".format(tmpdirname)
        click.secho("Creating Repo ...")
        kr = KnowledgeRepository.create_for_uri(uri=repo_uri, config=repo_config)

        rel_path = str(post.relative_to(repo))
        click.secho("Adding {} ...".format(rel_path))
        kp = KnowledgePost.from_file(str(post), fmt="block")
        kp.path = rel_path
        kr.add(kp, path=rel_path, update=True)

        click.secho("Starting the App ...")
        app_builder = get_app_builder(
            repo_uri,
            debug=False,
            db_uri=dburi,
            config=None,
            INDEXING_ENABLED=False,
            **ANONYMOUS_APP_SETTINGS
        )

        if not nobrowser:
            kp_path = kr._kp_path(rel_path)  # pylint:disable=protected-access
            url = "http://{}:{}/post/{}".format(host, port, kp_path)
            threading.Timer(1.25, lambda: webbrowser.open(url)).start()

        KnowledgeDeployer.using("flask")(app_builder, host=host, port=port).run(
            use_reloader=False
        )


@cli.command()
@repo_option
@post_argument
def lint(repo, posts):
    """
    Run linters on a block.
    """
    return_code = False
    if len(posts) > 1:
        click.secho("Linting modified blocks:")
        for post in posts:
            click.secho("- {}".format(post))

    for post in posts:
        click.secho("\nLinting {}:\n".format(post), fg="cyan")

        # detect files
        py_files = list(post.rglob("*.py"))
        if not py_files:
            raise click.UsageError("No python files found in path '{}'.".format(post))

        test_dir = set(str(path) for path in post.rglob("test/**/*.py"))
        tests_dir = set(str(path) for path in post.rglob("tests/**/*.py"))

        test_files = test_dir | tests_dir
        rcps_files = [str(path) for path in py_files if str(path) not in test_files]

        cmd_lint_recipes = [
            "pylint",
            "--disable",
            "duplicate-code,missing-docstring,trailing-newlines",
        ] + list(rcps_files)

        cmd_flake = ["flake8"] + list(py_files)

        click.secho("=> pylint: block files", fg="magenta")
        lint_recipes_return = subprocess.run(
            cmd_lint_recipes, cwd=repo, check=False
        ).returncode

        lint_tests_return = 0
        if test_files:
            cmd_lint_test = [
                "pylint",
                "--disable",
                "missing-docstring,redefined-outer-name,"
                + "duplicate-code,no-self-use,protected-access",
            ] + list(test_files)
            click.secho("=> pylint: test files", fg="magenta")
            lint_tests_return = subprocess.run(
                cmd_lint_test, cwd=repo, check=False
            ).returncode

        if lint_recipes_return == lint_tests_return == 0:
            click.secho("Success.", fg="green")
        else:
            click.secho("Pylint failed.", fg="red")

        click.secho("\n=> flake8", fg="magenta")
        flake_return = subprocess.run(cmd_flake, cwd=repo, check=False).returncode
        if flake_return == 0:
            click.secho("Success.", fg="green")
        else:
            click.secho("flake8 failed.", fg="red")

        return_code |= lint_recipes_return | lint_tests_return | flake_return

    sys.exit(int(return_code))


@cli.command()
@repo_option
@post_argument
@click.option(
    "--report-folder",
    help="Folder to export coverage report",
    type=click.Path(
        exists=True, file_okay=False, dir_okay=True, resolve_path=True, writable=True
    ),
    prompt=False,
    default=None,
)
def test(repo, posts, report_folder):
    """
    Run tests on a block.
    """
    return_code = False

    if len(posts) > 1:
        click.secho("Testing modified blocks:")
        for post in posts:
            click.secho("- {}".format(post))

    for post in posts:
        click.secho("\nTesting {}:\n".format(post), fg="cyan")
        cmd = [
            "pytest",
            "--cov-report",
            "term-missing",
            "--cov={}".format(post),
            "--no-cov-on-fail",
            "-ra",
            str(post),
        ]

        if report_folder:
            cmd = cmd + [
                "--cov-report",
                "xml:{}/coverage_{}.xml".format(report_folder, os.path.split(post)[-1]),
            ]
        completed = subprocess.run(cmd, cwd=str(repo), check=False)

        # pytest returns a 5 if no tests were collected
        return_code |= completed.returncode not in [0, 5]

    sys.exit(int(return_code))


@cli.command(hidden=True)
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str)
def reindex(repo, dburi):
    """
    Command for force reindex of the app. Separated from the main to avoid issues for db issues during serving with
    Gunicorn.
    Todo delete after QB_knowledge_repo will be update
    """
    _get_app(
        repo,
        db_uri=dburi,
        debug=False,
        INDEXING_ENABLED=True,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=True,
    ).db_update_index(reindex=True, check_timeouts=False, force=True)
    click.secho("Reindexing finished")


@cli.command(hidden=True)
@repo_option
@click.option("--dburi", help="The SQLAlchemy database uri.", type=str)
def db_upgrade(repo, dburi):
    """
    Command for manual database upgrade.
    Todo delete after QB_knowledge_repo will be update
    """
    _get_app(
        repo,
        db_uri=dburi,
        debug=True,
        INDEXING_ENABLED=False,
        INDEXING_UPDATES_REPOSITORIES_WITHOUT_LOCK=False,
    ).db_upgrade()


def _print_success_message(path):
    width = _environ_cols_wrapper()(sys.stdout) or 0
    click.secho("\n\n" + "=" * width, fg="green", bold=True)
    click.secho("Here is your new block:\n", fg="green", bold=True)
    try:
        tree = "\n".join(
            subprocess.run(["tree", path], check=True, capture_output=True)
            .stdout.strip()
            .decode()
            .lower()
            .strip()
            .split("\n")[:-2]
        )
    except Exception:  # pylint: disable=broad-except
        tree = str(path)

    click.secho(tree, fg="bright_green")
    path = str(Path(path).relative_to(Path(Path.cwd())))
    click.secho("\nTips", fg="bright_red", bold=True)
    click.secho("====", fg="bright_red", bold=True)
    click.secho("    * Keep up to date the metadata at the top of ", nl=False)
    click.secho("post.ipynb", fg="bright_yellow", bold=True)
    click.secho("    * Put all your source files in ", nl=False)
    click.secho("src/*", fg="bright_yellow", bold=True)
    click.secho("    * Put all your tests in ", nl=False)
    click.secho("tests/*", fg="bright_yellow", bold=True)
    click.secho("    * Put all your dependencies in ", nl=False)
    click.secho("requirements.txt", fg="bright_yellow", bold=True)
    click.secho("    * Demonstrate the usage of your code in ", nl=False)
    click.secho("post.ipynb", fg="bright_yellow", bold=True)
    click.secho("    * Make sure your code is up to standards by running")
    click.secho("          brix test {}".format(path), fg="magenta")
    click.secho("          brix lint {}".format(path), fg="magenta")
    click.secho("    * See your post at any time using ")
    click.secho("          brix preview " + path, fg="magenta")
    click.secho("    * When ready, create a new branch and ", nl=False)
    click.secho("open a PR\n", fg="bright_yellow", bold=True)
    click.secho("For more information visit ", nl=False)
    click.secho("one.quantumblack.com/docs/brix\n", fg="bright_blue", underline=True)
    click.secho(
        "Time to get 🏗 building; your fellow 👷‍♂️ engineers/scientists are\n"
        "🚧 looking forward to seeing your block 🧱!",
        fg="green",
    )


class BrixCliError(ClickException):
    """Exceptions generated from the brix CLI.

    Users should pass an appropriate message at the constructor.
    """

    def format_message(self):
        return style(
            fill(self.message, drop_whitespace=False), fg="red"
        )  # pragma: no cover


def _handle_exception(msg, end=True):
    """Pretty print the current exception then exit."""
    if _VERBOSE:
        click.secho(traceback.format_exc(), nl=False, fg="yellow")
    else:
        etype, value, _ = sys.exc_info()
        if etype != click.exceptions.Abort:
            click.secho(
                "".join(*traceback.format_exception_only(etype, value))
                + "Run with --verbose to see the full exception",
                fg="yellow",
            )
    if end:
        raise BrixCliError(msg)
    click.secho("Error: " + msg, fg="red")  # pragma: no cover


def main():  # pragma: no cover
    """
    Main entry point
    """
    cli()  # pylint: disable=no-value-for-parameter


if __name__ == "__main__":  # pragma: no cover
    main()
