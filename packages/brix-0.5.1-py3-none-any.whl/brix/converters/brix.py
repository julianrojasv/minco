# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.
"""
Converter class for brix knowledge post folders
"""
from pathlib import Path

import nbformat

from .base import KnowledgePostConverter
from .ipynb import nb_to_md


class BrixConverter(KnowledgePostConverter):
    """
    Converter between a "block" folder structure and a knowledge post
    """

    _registry_keys = ["block"]

    def from_file(self, filename: str, **opts):
        """
        Create a knowledge post from a "block" folder.

        Args:
            filename: path of the block folder
            opts: for compatibility reasons; ignored

        Raises:
            ValueError: if input folder structure is not valid
        """
        block_dir = Path(filename)
        if not block_dir.is_dir():
            raise ValueError("`filename` must point to an existing directory.")

        post_nb = block_dir / "post.ipynb"
        if not post_nb.exists():
            raise ValueError(
                "The block directory must contain a file called `post.ipynb`."
            )

        post_uuid = block_dir / "UUID"
        if not post_uuid.exists():
            raise ValueError("The block directory must contain a file called `UUID`.")

        nb = nbformat.read(str(post_nb), as_version=4)
        body, resources = nb_to_md(nb)
        self.kp_write(
            body,
            images={
                name.split("images/")[1]: data
                for name, data in resources.get("outputs", {}).items()
            },
        )

        with post_uuid.open("r") as io:
            uuid = io.read().strip()
        self.kp.uuid = uuid

        # Add cleaned ipynb file
        for cell in nb["cells"]:
            if cell["cell_type"] == "code":
                cell["outputs"] = []  # remove output data
                cell["execution_count"] = None  # reset to not executed
        self.kp.write_src(str(post_nb.name), nbformat.writes(nb))

        # add src files
        rcp_files_abs = [
            elem
            for elem in block_dir.rglob("*")
            if elem.is_file()
            and "__pycache__" not in str(elem)
            and "/." not in str(elem)  # hidden files / folders
            and elem.name != "UUID"
        ]
        rcp_files_rel = [abs_file.relative_to(block_dir) for abs_file in rcp_files_abs]

        for abs_file, rel_file in zip(rcp_files_abs, rcp_files_rel):
            if abs_file.samefile(post_nb):  # no need to add notebook
                continue
            try:
                with abs_file.open("r") as f:
                    self.kp.write_src(str(rel_file), f.read())
            except Exception:  # pylint: disable=broad-except
                self.kp.write_src(str(rel_file), "Binary file")

    def to_file(self, filename, **opts):
        raise NotImplementedError

    def to_string(self, **opts):
        raise NotImplementedError
