# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa

from functools import wraps
from pathlib import Path

from brix.postprocessors import KnowledgePostProcessor
from brix.utils.registry import SubclassRegisteringABCMeta


def get_format(filename, fmt=None):
    fmt = fmt or Path(filename).suffix[1:]  # without "."
    if not fmt:
        raise RuntimeError(
            "Unable to determine a format automatically. "
            "Please manually specify the format, and try again."
        )
    return fmt


class KnowledgePostConverter(metaclass=SubclassRegisteringABCMeta):
    _registry_keys = None  # File extensions

    def __init__(self, kp, fmt=None, postprocessors=None, **kwargs):
        self.kp = kp
        self.fmt = fmt
        self.postprocessors = postprocessors or []
        self.init(**kwargs)

    @property
    def dependencies(self):
        return []

    def init(self):
        pass

    def __get_wrapped_with_postprocessors(self, f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            try:
                kp = self.kp
                f(*args, **kwargs)
                postprocessors = self.postprocessors

                if f.__name__ == "from_file":
                    filename = args[0] if len(args) > 0 else kwargs["filename"]
                    kp.orig_context = str(Path(filename))

                if postprocessors is None:
                    postprocessors = []
                for postprocessor, kwargs in postprocessors:
                    KnowledgePostProcessor._get_subclass_for(postprocessor)(
                        **kwargs
                    ).process(kp)

                return kp
            finally:
                self.cleanup()

        return wrapped

    def __getattribute__(self, attr):
        if attr in ["from_file", "from_string"]:
            return self.__get_wrapped_with_postprocessors(
                object.__getattribute__(self, attr)
            )
        return object.__getattribute__(self, attr)

    def kp_write(self, md, headers=None, images=None):
        images = images or {}
        return self.kp.write(md, headers=headers, images=images)

    def from_file(self, filename, **opts):
        raise NotImplementedError

    def to_file(self, filename, **opts):
        raise NotImplementedError

    def to_string(self, **opts):
        raise NotImplementedError

    def cleanup(self):
        pass

    @classmethod
    def for_file(cls, kp, filename, fmt=None, postprocessors=None):
        return cls.for_format(
            kp, get_format(filename, fmt), postprocessors=postprocessors
        )

    @classmethod
    def for_format(cls, kp, fmt, postprocessors=None):
        if fmt.lower() not in cls._registry:
            raise ValueError(
                "The knowledge repository does not support files of type '{}'. Supported types are: {}.".format(
                    fmt, ",".join(list(cls._registry.keys()))
                )
            )
        return cls._get_subclass_for(fmt.lower())(
            kp, fmt=format, postprocessors=postprocessors
        )
