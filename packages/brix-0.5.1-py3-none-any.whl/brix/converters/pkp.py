# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa

import io
import os
import zipfile

from .base import KnowledgePostConverter


class PkpConverter(KnowledgePostConverter):
    _registry_keys = ["kp", "zip"]

    def to_file(self, filename):
        zf = zipfile.ZipFile(filename, "w")

        for ref in self.kp._dir():
            zf.writestr(ref, self.kp._read_ref(ref))

        zf.close()

    def to_string(self):
        data = io.BytesIO()
        zf = zipfile.ZipFile(data, "w")

        for ref in self.kp._dir():
            zf.writestr(ref, self.kp._read_ref(ref))

        zf.close()
        data.seek(0)
        return data.read()

    def from_file(self, filename):
        # Note: header checks are not applied here, since it should not be
        # possible to create portable knowledge post with incorrect headers.
        zf = zipfile.ZipFile(filename, "r")

        for ref in zf.namelist():
            with zf.open(ref) as f:
                self.kp._write_ref(ref, f.read())

        zf.close()
