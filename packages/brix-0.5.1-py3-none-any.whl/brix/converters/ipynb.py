# QUANTUMBLACK CONFIDENTIAL
#
# Copyright (c) 2016 - present QuantumBlack Visual Analytics Ltd. All
# Rights Reserved.
#
# NOTICE: All information contained herein is, and remains the property of
# QuantumBlack Visual Analytics Ltd. and its suppliers, if any. The
# intellectual and technical concepts contained herein are proprietary to
# QuantumBlack Visual Analytics Ltd. and its suppliers and may be covered
# by UK and Foreign Patents, patents in process, and are protected by trade
# secret or copyright law. Dissemination of this information or
# reproduction of this material is strictly forbidden unless prior written
# permission is obtained from QuantumBlack Visual Analytics Ltd.

# modified from airbnb's knowledge repo
# pylint: skip-file
# flake8: noqa
"""
Helper functions plus converter class for ipynb notebooks
"""
import os

import nbformat
from jinja2 import DictLoader
from nbconvert import MarkdownExporter
from traitlets.config import Config

from .base import KnowledgePostConverter

__all__ = ["nb_to_md", "IpynbConverter"]

TEMPLATE = """
{%- extends 'markdown.tpl' -%}

{%- block data_javascript scoped %}
{% set div_id = uuid4() %}
<div id="{{ div_id }}"></div>
<div class="output_subarea output_javascript {{ extra_class }}">
<script type="text/javascript">
var element = $('#{{ div_id }}');
{{ output.data['application/javascript'] }}
</script>
</div>
{%- endblock -%}

{%- block input -%}
{%- if cell['metadata'].get('slideshow',{}).get('slide_type','') == 'skip' -%}
{%- else %}
```python
{{ cell.source }}
```
{%- endif %}
{%- endblock input -%}

{%- block data_priority scoped %}
{{ super() }}
{%- endblock %}


{# remove stderr output #}
{%- block stream scoped -%}
    {%- if output.name == 'stdout' -%}
        {{ super () }}
    {%- elif output.name == 'stderr' -%}
    {%- endif -%}
{%- endblock stream -%}
"""

CONF = Config()
CONF.ExtractOutputPreprocessor.output_filename_template = (
    "images/{unique_key}_{cell_index}_{index}{extension}"
)
CONF.NbConvertBase.display_data_priority = [
    "application/javascript",
    "text/html",
    "text/markdown",
    "image/svg+xml",
    "text/latex",
    "image/png",
    "image/jpeg",
    "text/plain",
]


def nb_to_md(nb: nbformat.NotebookNode):
    """
    Converts a notebook to markdown, applying additional formatting along the way.
    """
    loader = DictLoader({"full.tpl": TEMPLATE})
    md_exporter = MarkdownExporter(
        config=CONF, extra_loaders=[loader], template_file="full.tpl"
    )
    body, resources = md_exporter.from_notebook_node(nb)
    return body, resources


class IpynbConverter(KnowledgePostConverter):
    _registry_keys = ["ipynb"]

    def from_file(self, filename: str):
        nb = nbformat.read(filename, as_version=4)
        body, resources = nb_to_md(nb)
        self.kp_write(
            body,
            images={
                name.split("images/")[1]: data
                for name, data in resources.get("outputs", {}).items()
            },
        )

        # Add cleaned ipynb file
        for cell in nb["cells"]:
            if cell["cell_type"] == "code":
                cell["outputs"] = []  # remove output data
                cell["execution_count"] = None  # reset to not executed
        self.kp.write_src(os.path.basename(filename), nbformat.writes(nb))
