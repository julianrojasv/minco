# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""A combination of Kedro and GE's context"""
from datetime import datetime
from pathlib import Path
from typing import List, Tuple, Union

import great_expectations.exceptions as ge_exceptions
from great_expectations.core import ExpectationSuite, ExpectationSuiteValidationResult
from great_expectations.data_context import DataContext
from great_expectations.profile import BasicDatasetProfiler
from great_expectations.profile.base import DataAssetProfiler
from kedro.cli.utils import KedroCliError
from kedro.context import load_context

from kedro_great_expectations.kedro_datasets import KedroDataSets
from kedro_great_expectations.kedro_notebook_renderer import KedroNotebookRenderer

KEDRO_PANDAS_DATASOURCE = "kedro_pandas_datasource"
KEDRO_SPARK_DATASOURCE = "kedro_spark_datasource"


class KedroGEContext:
    """A combination of Kedro and GE's context.

    Args:
        env: The kedro environment to use.
        project_root: The root directory of the kedro project.
        dataset_filter: What filter to apply to kedro dataset names when doing any lookups.
        dataset_types: What dataset types to filter against when doing any lookups.
        locate_args: Command line input to filter down inputted datasets, passed to KedroDataSets
    """

    def __init__(
        self,
        env: str = None,
        project_root: Union[str, Path] = None,
        dataset_filter: str = None,
        dataset_types: List[str] = None,
        locate_args: List = None,
    ):
        self._env = env
        self._project_root = project_root
        self._dataset_filter = dataset_filter
        self._dataset_types = dataset_types
        self._locate_args = locate_args or []
        self._kedro_context = None
        self._ge_context = None
        self._kedro_datasets = None
        self._ds_names = None

    @property
    def kedro_context(self):
        """The Kedro context instance"""
        if self._kedro_context is None:
            project_root = self._project_root or Path.cwd()
            self._kedro_context = load_context(project_root, env=self._env)

        return self._kedro_context

    @property
    def ge_context(self):
        """The Great Expectations context instance."""
        if self._ge_context is None:
            try:
                context_dir = self.kedro_context.project_path / "great_expectations"
                self._ge_context = DataContext(context_dir)
            except ge_exceptions.ConfigNotFoundError:
                raise KedroCliError(
                    "Great Expectations configuration cannot be found. "
                    "Try running `kedro ge init` once in your root directory."
                )

        return self._ge_context

    @property
    def kedro_datasets(self):
        """Collection of Kedro datasets from Kedro's catalog"""
        if self._kedro_datasets is None:
            self._kedro_datasets = KedroDataSets(
                self.kedro_context.catalog,
                dataset_filter=self._dataset_filter,
                dataset_types=self._dataset_types,
            )
        return self._kedro_datasets

    @property
    def datasets(self):
        """A list of Kedro datasets, filtered to match the locate args"""
        return self.kedro_datasets.locate(*self._locate_args)

    @property
    def ds_names(self):
        """The set of dataset names"""
        if self._ds_names is None:
            self._ds_names = set(ds["ds_name"] for ds in self.datasets)
        return self._ds_names

    @property
    def ds_names_with_suites(self):
        """The set of datasets that have non-empty expectation suites"""
        return set(ds for ds in self.ds_names if self.has_suite(ds))

    @property
    def ds_names_without_suites(self):
        """The set of datasets that don't have expectation suites or have empty ones"""
        return set(ds for ds in self.ds_names if not self.has_suite(ds))

    def initialise_ge(self):
        """Initialise the great expectations directory in the kedro project root."""
        project_path = str(self.kedro_context.project_path)
        DataContext.create(project_path)
        self._populate_kedro_datasources()

    def has_suite(self, ds_name: str) -> bool:
        """Check whether the dataset specified by name has a non-empty
        expectation suite. Currently assumes a dataset has only one
        expectation suite with the same name.

        Args:
            ds_name: The name of the kedro datasets as specified in the catalog.

        Returns:
            True if the dataset has a corresponding non-empty expectation suite.
        """
        try:
            suite = self.ge_context.get_expectation_suite(ds_name)
        except ge_exceptions.DataContextError:
            return False
        return bool(suite.expectations)

    def generate(
        self,
        ds_name: str,
        empty=False,
        profiler: DataAssetProfiler = BasicDatasetProfiler,
    ) -> ExpectationSuite:
        """Generate an expectation suite for a dataset."""
        suite = self.ge_context.create_expectation_suite(ds_name)
        if empty:
            return suite

        batch_kwargs = self._get_batch_kwargs(ds_name)
        batch = self.ge_context.get_batch(
            batch_kwargs=batch_kwargs,
            expectation_suite_name=suite.expectation_suite_name,
        )
        suite, _ = profiler.profile(batch)

        self.ge_context.save_expectation_suite(suite)
        return suite

    def profile(
        self,
        ds_name: str,
        suite_name: str = None,
        profiler: DataAssetProfiler = BasicDatasetProfiler,
    ) -> Tuple[ExpectationSuite, ExpectationSuiteValidationResult]:
        """Profile a dataset"""
        name = suite_name or ds_name
        batch_kwargs = self._get_batch_kwargs(ds_name)

        result = self.ge_context.profile_data_asset(
            KEDRO_PANDAS_DATASOURCE,
            batch_kwargs=batch_kwargs,
            expectation_suite_name=name,
            profiler=profiler,
        )

        suite, result = result["results"][0]

        return suite, result

    def validate(self, ds_name: str, suite_name: str = None, run_id: str = None):
        """Validate a dataset"""
        suite_name = suite_name or ds_name

        batch_kwargs = self._get_batch_kwargs(ds_name)
        batch = self.ge_context.get_batch(
            batch_kwargs=batch_kwargs, expectation_suite_name=suite_name
        )

        if run_id is None:
            run_id = datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ")

        results = self.ge_context.run_validation_operator(
            "action_list_operator", assets_to_validate=[batch], run_id=run_id
        )

        return results

    def edit(self, suite_name: str):
        """Edit the suite corresponding to suite_name"""
        try:
            suite = self.ge_context.get_expectation_suite(suite_name)
        except ge_exceptions.DataContextError:
            raise KedroCliError(
                "Expectation suite {} not found. "
                "Try running `kedro ge generate`.".format(suite_name)
            )

        project_path = self.kedro_context.project_path
        nb_name = "{}.ipynb".format(suite_name)

        notebook_path = project_path / "great_expectations" / "uncommitted" / nb_name

        if not notebook_path.exists():
            KedroNotebookRenderer().render_to_disk(suite, notebook_path)

        return notebook_path

    def _populate_kedro_datasources(self):
        self.ge_context.add_datasource(
            KEDRO_PANDAS_DATASOURCE, class_name="PandasDatasource"
        )
        self.ge_context.add_datasource(
            KEDRO_SPARK_DATASOURCE, class_name="SparkDFDatasource"
        )

    def _get_batch_kwargs(self, ds_name: str):
        dataset = self.kedro_context.catalog.load(ds_name)
        datasource = _classify_datasource(dataset, ds_name)
        return {"dataset": dataset, "datasource": datasource}


def _classify_datasource(dataset, ds_name: str):
    module = dataset.__module__

    if module == "pandas.core.frame":
        return KEDRO_PANDAS_DATASOURCE
    if module == "pyspark.sql.dataframe":
        return KEDRO_SPARK_DATASOURCE
    raise KedroCliError(
        "Dataset {} from module {} is not supported. Currently, "
        "only pandas and pyspark datasets are allowed.".format(ds_name, module)
    )
