# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""Kedro Datasets"""

import re
from itertools import chain, groupby
from typing import Any, Dict, List, Set, Tuple, Union

from kedro.cli.utils import KedroCliError
from kedro.io import DataCatalog

KEDRO_DATASET_MODULES = ("kedro.io", "kedro.extras.datasets", "kedro.contrib.io")
KEDRO_PANDAS_MODULES = (".pandas", ".csv_", ".excel_", ".hdf_", ".parquet_")
KEDRO_SPARK_MODULES = (".spark", ".pyspark")
DATASET_NOT_FOUND_MSG = (
    "Dataset `{}` does not exist. Please run `kedro ge list` "
    "to see the valid dataset names.\n\nTip: You can reference "
    "datasets with their name or number. You can specify "
    "multiple datasets using space delimited values and ranges. "
    "E.g. kedro ge validate 1:3 5:6 10"
)


class KedroDataSets:
    """Class that stores the datasets available in the current Kedro project."""

    def __init__(
        self,
        catalog: DataCatalog,
        dataset_filter: str = None,
        dataset_types: Set[str] = None,
    ):
        self._catalog = catalog
        self._dataset_filter = dataset_filter
        self._dataset_types = dataset_types
        self._datasets = None

    @property
    def datasets(self):
        """Sorted datasets"""
        if self._datasets is None:
            self._datasets = self._sort_datasets(
                self._dataset_filter, self._dataset_types
            )

        return self._datasets

    def group_by_type(self) -> List[Tuple[str, List[Dict]]]:
        """Get sorted list of datasets grouped by dataset type.

        Returns: List of 2-tuples of the form: (dataset type,
            list of sorted datasets).
        """
        return [
            (ds_type, sorted(datasets, key=lambda y: y["index"]))
            for ds_type, datasets in groupby(self.datasets, key=lambda x: x["ds_type"])
        ]

    def locate(self, *datasets: Union[int, str]) -> List[Dict[str, Any]]:
        """Locate the dataset based on its name or index.

        Args:
            datasets: One of the following:
                a) dataset name
                b) list of dataset names
                c) dataset index (as returned by `kedro ge list`)
                d) range of dataset indices (e.g., 1:5).

        Returns:
            List of dictionaries with the information about the specified datasets.
        """
        if not datasets:
            return self.datasets

        resolved = []
        names = set()
        for ds in chain.from_iterable(self._locate(str(ds)) for ds in datasets):
            if ds["ds_name"] not in names:
                names.add(ds["ds_name"])
                resolved.append(ds)

        return resolved

    def _sort_datasets(
        self, filter_: str = None, types: Set[str] = None
    ) -> List[Dict[str, Any]]:
        datasets = (
            {"ds_type": type(dataset).__name__, "ds_name": name}
            for name, dataset in self._catalog._data_sets.items()
            if not _is_parameter(name) and _is_supported(dataset)
        )

        datasets = sorted(datasets, key=lambda x: (x["ds_type"], x["ds_name"]))
        datasets = [{**ds, "index": idx} for idx, ds in enumerate(datasets, 1)]

        if filter_:
            datasets = [ds for ds in datasets if re.match(filter_, ds["ds_name"])]
        if types:
            datasets = [ds for ds in datasets if ds["ds_type"] in types]

        return datasets

    def _parse_number(self, idx: Union[str, int]) -> List[Dict[str, Any]]:
        idx = int(idx.strip() if isinstance(idx, str) else idx)
        for dataset in self.datasets:
            if dataset["index"] == idx:
                return [dataset]
        raise KedroCliError(DATASET_NOT_FOUND_MSG.format(str(idx)))

    def _parse_range(self, range_: str) -> List[Dict[str, Any]]:
        range_ = range_.split(":")
        if len(range_) > 2:
            raise KedroCliError(
                "Index range must contain only one delimiting character `:`."
            )
        if len(range_) < 2:
            raise ValueError
        left, right = range_
        left = int(left.strip()) if left.strip() else 1
        right = int(right.strip()) if right.strip() else len(self.datasets)
        range_ = range(left, right - 1, -1) if left > right else range(left, right + 1)
        return [self._parse_number(num)[0] for num in range_]

    def _locate(self, name: str) -> List[Dict[str, Any]]:
        for func in (self._parse_range, self._parse_number):
            try:
                return func(name)
            except ValueError:
                pass
        for ds in self.datasets:
            if ds["ds_name"] == name:
                return [ds]
        raise KedroCliError(DATASET_NOT_FOUND_MSG.format(name))


def _is_parameter(ds_name):
    return ds_name == "parameters" or ds_name.startswith("params:")


def _is_supported(ds):
    try:
        module = ds.__module__
    except AttributeError:
        return False

    possible_modules = KEDRO_PANDAS_MODULES + KEDRO_SPARK_MODULES

    if any(possible_path in module for possible_path in KEDRO_DATASET_MODULES):
        return any(possible_module in module for possible_module in possible_modules)

    return True
