# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""Kedro specific notebook renderer"""

from great_expectations.render.renderer.notebook_renderer import NotebookRenderer

HEADER = """\
# Edit Your Expectation Suite
Use this notebook to recreate and modify your expectation suite:

**Expectation Suite Name**: `{}`
"""

INITIAL_CELL = """\
from datetime import datetime
import great_expectations as ge
import great_expectations.jupyter_ux
from great_expectations.data_context.types.resource_identifiers import ValidationResultIdentifier

data_context = ge.data_context.DataContext()

expectation_suite_name = "{suite_name}"
suite = data_context.get_expectation_suite(expectation_suite_name)
suite.expectations = []

# Use kedro to load the dataset:
batch_kwargs = {{"dataset": catalog.load("{suite_name}"), "datasource": "kedro_pandas_datasource"}}
batch = data_context.get_batch(batch_kwargs, suite.expectation_suite_name)
batch.head()
"""

FOOTER = """\
## Save Your Expectations

Let's save the expectation suite as a JSON file in the `great_expectations/expectations` directory of your project.
If you decide not to save some expectations that you created, use [remove_expectaton method](https://docs.greatexpectations.io/en/latest/module_docs/data_asset_module.html?highlight=remove_expectation&utm_source=notebook&utm_medium=edit_expectations#great_expectations.data_asset.data_asset.DataAsset.remove_expectation).
"""

FINAL_CELL = """batch.save_expectation_suite(discard_failed_expectations=False)"""

OPTIONAL_VALIDATION_FOOTER = """\
## Review your Expectations (optional)

Let's now run the validation operators against your expectation suite and rebuild your Data Docs, which helps you communicate about your data with both machines and humans.
"""

OPTIONAL_VALIDATION_CELL = """\
run_id = datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ")

results = data_context.run_validation_operator("action_list_operator", assets_to_validate=[batch], run_id=run_id)
expectation_suite_identifier = list(results["details"].keys())[0]
validation_result_identifier = ValidationResultIdentifier(
    expectation_suite_identifier=expectation_suite_identifier,
    batch_identifier=batch.batch_kwargs.to_id(),
    run_id=run_id
)
data_context.build_data_docs()
data_context.open_data_docs(validation_result_identifier)
"""


class KedroNotebookRenderer(NotebookRenderer):
    """A Kedro specific version of the notebook renderer."""

    def add_header(self, suite_name, batch_kwargs):
        self.add_markdown_cell(HEADER.format(suite_name))
        self.add_code_cell(
            INITIAL_CELL.format(suite_name=suite_name), lint=True,
        )

    def add_footer(self):
        self.add_markdown_cell(FOOTER)
        self.add_code_cell(FINAL_CELL)
        self.add_markdown_cell(OPTIONAL_VALIDATION_FOOTER)
        self.add_code_cell(OPTIONAL_VALIDATION_CELL)
