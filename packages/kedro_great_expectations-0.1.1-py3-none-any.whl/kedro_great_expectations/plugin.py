# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Kedro plugin for integration with Great Expectations
(https://greatexpectations.io)
"""
import platform
import subprocess
import sys
import textwrap
from datetime import datetime
from typing import Any, Dict

import click
from great_expectations import __version__ as ge_version
from great_expectations.data_context.types.resource_identifiers import (
    ExpectationSuiteIdentifier,
)
from great_expectations.exceptions import DataContextError
from kedro import __version__ as kedro_version
from kedro.io.core import DataSetError
from log_symbols import LogSymbols

from kedro_great_expectations import __version__ as plugin_version
from kedro_great_expectations.kedro_ge_context import KedroGEContext

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
VERSION_MESSAGE = (
    "Kedro-Great_Expectations: {}, Kedro: {}, Great Expectations: {}, "
    "Python: {}, {}: {}".format(
        plugin_version,
        kedro_version,
        ge_version,
        platform.python_version(),
        platform.system(),
        platform.release(),
    )
)
EMPTY_GEN_ARG_HELP = "Don't autogenerate expectations"
ENV_ARG_HELP = "What kedro environment to use when looking up datasets"
FILTER_ARG_HELP = "Glob pattern to filter dataset names with"
TYPE_ARG_HELP = "Filter dataset types using their str name"
ONLY_SUITES_ARG_HELP = "Only list datasets that have non-empty expectation suites"
VERBOSE_ARG_HELP = "Verbose output for validation"
GROUP_ARG_HELP = "Group all validations under a single run_id"
JUPYTER_IP_HELP = "IP address of the Jupyter server."
JUPYTER_ALL_KERNELS_HELP = "Display all available Python kernels."
JUPYTER_IDLE_TIMEOUT_HELP = """When a notebook is closed, Jupyter server will
terminate its kernel after so many seconds of inactivity. This does not affect
any open notebooks."""

ENV_OPTION = click.option(
    "--env",
    "-e",
    type=str,
    default=None,
    multiple=False,
    envvar="KEDRO_ENV",
    help=ENV_ARG_HELP,
)

FILTER_OPTION = click.option(
    "--filter",
    "-f",
    "filter_",
    type=str,
    default=None,
    multiple=None,
    help=FILTER_ARG_HELP,
)

TYPE_OPTION = click.option(
    "--type", "-t", "types", type=str, multiple=True, help=TYPE_ARG_HELP
)

DATASET_ARGUMENT = click.argument("datasets", nargs=-1)


@click.group(name="Great_Expectations")
def commands():
    """Kedro plugin for interacting with Great Expectations"""


@commands.group(name="ge", context_settings=CONTEXT_SETTINGS)
@click.version_option(
    plugin_version,
    "-V",
    "--version",
    message=VERSION_MESSAGE,
    help="Show version and exit",
)
def ge_group():
    """Kedro plugin for interacting with Great Expectations"""


@ge_group.command(name="init")
def ge_init():
    """Initialise a kedro great expectations project"""
    context = KedroGEContext()
    context.initialise_ge()
    click.secho("Great Expectations initialised in your kedro project", fg="green")


@ge_group.command(name="list")
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option(
    "--only-suites", "-o", is_flag=True, default=False, help=ONLY_SUITES_ARG_HELP
)
def ge_list(filter_, env, types, only_suites):
    """List all kedro datasets. Those that have
    non-empty expectation suites are in cyan.
    """
    context = KedroGEContext(env=env, dataset_filter=filter_, dataset_types=types)

    def _format_dataset(dataset):
        fmt = "[{ds[index]}] {ds[ds_name]}".format(ds=dataset)
        fmt = textwrap.indent(fmt, " " * 2)
        fg_color = "cyan" if context.has_suite(dataset["ds_name"]) else None
        return click.style(fmt, fg=fg_color)

    for ds_type, ds_list in context.kedro_datasets.group_by_type():
        if only_suites:
            ds_list = [ds for ds in ds_list if context.has_suite(ds["ds_name"])]
        ds_list = [_format_dataset(ds) for ds in ds_list]
        if ds_list:
            click.secho(ds_type, bold=True, fg="green")
            click.secho("\n".join(ds_list))


@ge_group.command(name="profile")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
def ge_profile(datasets, filter_, env, types):
    """Profile your kedro datasets using great expectations"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )
    for ds_name in context.ds_names:
        suite_name = "{}_profile".format(ds_name)
        try:
            context.profile(ds_name, suite_name=suite_name)
            message = "Profiled dataset {} succesfully".format(ds_name)
            symbol = LogSymbols.SUCCESS.value
        except DataSetError:
            message = "Could not load dataset {}".format(ds_name)
            symbol = LogSymbols.ERROR.value
        _echo_symbol(symbol, message)


@ge_group.command(name="validate")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option("--verbose", "-v", is_flag=True, default=False, help=VERBOSE_ARG_HELP)
@click.option("--group", "-g", is_flag=True, default=False, help=GROUP_ARG_HELP)
def ge_validate(datasets, filter_, env, types, verbose, group):
    """Validate your kedro datasets against existing expectation suites"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )
    run_id = datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ") if group else None

    for ds in context.ds_names_without_suites:
        ds = click.style(ds, fg="cyan")
        message = "Skipping validation of {}: no expectation suite found".format(ds)
        _echo_symbol(LogSymbols.INFO.value, message)

    exit_code = 0
    for ds in context.ds_names_with_suites:
        results = context.validate(ds, run_id=run_id)
        if not results["success"]:
            exit_code = 1
        messages = _parse_validation_results(ds, results, verbose)

        for symbol, message, indent in messages:
            _echo_symbol(symbol, message, indent=indent)

    sys.exit(exit_code)


@ge_group.command(name="generate")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option("--empty", is_flag=True, default=False, help=EMPTY_GEN_ARG_HELP)
def ge_generate(datasets, filter_, env, types, empty):
    """Generate expectation suites for your kedro datasets"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )

    for ds in context.ds_names_with_suites:
        message = "Expectation suite {} already exists".format(ds)
        _echo_symbol(LogSymbols.INFO.value, message)

    for ds in context.ds_names_without_suites:

        message = "Generated prefilled expectation suite {}".format(ds)
        if empty:
            message = "Generated empty expectation suite {}".format(ds)

        try:
            context.generate(ds, empty=empty)
            symbol = LogSymbols.SUCCESS.value
        except DataContextError as ex:
            message = "Failed to generate expectation suite {} with error {}".format(
                ds, ex
            )
            symbol = LogSymbols.ERROR.value

        _echo_symbol(symbol, message)


# pylint: disable=invalid-name
@ge_group.command(name="edit")
@ENV_OPTION
@click.option("--ip", type=str, default=None, help=JUPYTER_IP_HELP)
@click.option(
    "--all-kernels", is_flag=True, default=None, help=JUPYTER_ALL_KERNELS_HELP
)
@click.option("--idle-timeout", type=int, default=None, help=JUPYTER_IDLE_TIMEOUT_HELP)
@click.argument("name")
def ge_edit(env, ip, all_kernels, idle_timeout, name):
    """Edit expectation suite for a kedro dataset."""
    context = KedroGEContext(env=env)

    notebook_path = context.edit(name)

    options = _get_jupyter_options(env, ip, all_kernels, idle_timeout)
    subprocess.call(["kedro", "jupyter", "notebook", *options, notebook_path])


@ge_group.command(name="docs")
def ge_open():
    """Open the data docs"""
    context = KedroGEContext()
    context.ge_context.build_data_docs()
    context.ge_context.open_data_docs()


def _echo_symbol(symbol, message, indent=None, **kwargs):
    message = "[{}] {}".format(symbol, message)
    if indent:
        message = textwrap.indent(message, " " * indent)

    click.secho(message, **kwargs)


# pylint: disable=invalid-name
def _get_jupyter_options(env, ip, all_kernels, idle_timeout):
    options = []
    if env:
        options.extend(["--env", env])
    if ip:
        options.extend(["--ip", str(ip)])
    if all_kernels:
        options.append("--all-kernels")
    if idle_timeout:
        options.extend(["--idle-timeout", str(idle_timeout)])

    return options


def _parse_validation_results(ds_name: str, results: Dict[str, Any], verbose: bool):
    messages = []
    if results["success"]:
        ds = click.style(ds_name, fg="green")
        message = "Expectation suite for {} passed".format(ds)
        symbol = LogSymbols.SUCCESS.value
    else:
        ds = click.style(ds_name, fg="red")
        message = "Expectation suite for {} failed".format(ds)
        symbol = LogSymbols.ERROR.value

    messages.append((symbol, message, None))

    if verbose:
        suite_id = ExpectationSuiteIdentifier(ds_name)
        validations = results["details"][suite_id]["validation_result"]["results"]
        for validation in validations:
            symbol, message = _verbose_message(validation)
            messages.append((symbol, message, 4))

    return messages


def _verbose_message(validation):
    rule = validation.expectation_config.expectation_type
    rule = click.style(rule, fg="yellow")
    details = validation.expectation_config.kwargs
    if validation.success:
        message = "Rule {} passed".format(rule)
        symbol = LogSymbols.SUCCESS.value
    else:
        message = "Rule {} failed".format(rule)
        symbol = LogSymbols.ERROR.value

    column = details.get("column")
    if column:
        column = click.style(column, fg="blue")
        message = "{} for column {}".format(message, column)
    return symbol, message
