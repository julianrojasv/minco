# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""
Functional utilities.
"""

from copy import deepcopy
from functools import partial
from typing import Any, Callable, List, Union

import numpy as np
import pandas as pd

from optimizer.types import Predictor, Matrix, Vector


class _Chainer:
    """
    Class to hold a list of arguments given to chain.
    This avoids the issue that the result of chain will not be pickleable.
    """

    def __init__(self, args: List[Union[Callable, Predictor]]):
        """Constructor.

        Args:
            args: argument list.
        """
        self.args = args

    def __call__(self, x: Any) -> Any:
        """Call the argument callables / predictors in order.

        Args:
            x: input argument to the composed functions.

        Returns:
            Output of the composed functions.
        """
        out = x

        for f in self.args:
            if hasattr(f, "predict"):
                out = f.predict(out)

            else:
                out = f(out)

        return out


def chain(*args: Union[Callable, Predictor]) -> Callable:
    """Chain a list of single argument callables and/or models.

    Calls the first, then second, and so on through the provided arguments.

    Args:
        args: list of callables.

    Returns:
        Callable.
    """
    return _Chainer(args)


def safe_subset(parameters: Matrix, col: Union[str, int]) -> Vector:
    """Safely index into a parameter matrix based off its type.

    Args:
        parameters: Matrix to index into.
        col: str or int, column specifier.

    Returns:
        Matrix or vector, the subset parameters matrix.
    """
    if isinstance(parameters, np.ndarray):
        return parameters[:, col]

    else:
        return parameters[col]


def safe_assign(
    parameters: Matrix,
    values: Vector,
    col: Union[str, int],
    row_mask: Union[Vector, List] = None,
) -> Matrix:
    """Safely assigns a column of a matrix to the provided values.

    Args:
        parameters: Matrix to assign values to.
        values: values to assign.
        col: which column to put values into.
        row_mask: optional row mask.
            Must be a boolean type with len(row_mask) == parameter.shape[1].

    Returns:
        Matrix, with the updated column.

    Raises:
        ValueError: if values is 1 dimensional.
        ValueError: if the provided row_mask is a different length and values.
    """
    values = np.array(values)

    if values.ndim != 1:
        raise ValueError("Values must be a Vector.")

    if row_mask is not None and len(row_mask) != len(values):
        raise ValueError("Length and shape of row_mask must be the same as values.")

    parameters_copy = deepcopy(parameters)

    if isinstance(parameters, np.ndarray):
        row_mask = slice(None) if row_mask is None else row_mask

        parameters_copy[row_mask, col] = values[row_mask]

    else:
        if row_mask is None:
            parameters_copy[col] = values

        else:
            # This fixed a problem caused by DatetimeIndex.
            row_mask = pd.Series(row_mask)
            row_mask.index = parameters_copy.index

            parameters_copy.loc[row_mask, col] = values[row_mask]

    return parameters_copy


def column(col: Union[str, int]) -> Callable:
    """Returns a function that will handle indexing a given Matrix.
    This function is used to get around using lambdas in constraint definitions that
    would not allow pickling.

    Args:
        col: string or integer column name.

    Returns:
        Callable.
    """
    return partial(safe_subset, col=col)
