# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""
Repair module.
"""

from copy import deepcopy
from typing import Callable, List, Union

from optimizer.constraint.constraint import (
    BaseConstraint,
    SetMembershipConstraint,
    constraint,
)
from optimizer.constraint.handler import BaseHandler
from optimizer.constraint.sets import ConstraintSet
from optimizer.exceptions import InvalidConstraintError
from optimizer.types import Matrix, Vector
from optimizer.utils.functional import column, safe_assign


class Repair(BaseHandler):
    """
    Represents a repair function for a single column.
    """

    def __init__(
        self,
        constraint_: BaseConstraint,
        repair_func: Callable,
        repair_column: Union[str, int],
    ):
        """Constructor

        Args:
            constraint_: BaseConstraint object representing the
                constraint being repaired.
            repair_func: function to apply as a repair.
            repair_column: which column index to select for repair.

        Raises:
            InvalidConstraintError: if repair_func is not callable.
        """
        super(Repair, self).__init__(constraint_)

        self.repair_column = repair_column

        if not callable(repair_func):
            raise InvalidConstraintError("Repair function must be callable.")

        self.repair_func = repair_func

        # Stored values for logging.
        self.repaired_values = None

    def __call__(self, parameters: Matrix) -> Matrix:
        """Repair and return a matrix.

        Args:
            parameters: Matrix to be repaired.

        Returns:
            The repaired matrix.
        """
        self.constraint(parameters)

        violated = self.constraint.violated

        self.repaired_values = self.repair_func(self.constraint_values)

        return safe_assign(
            parameters, self.repaired_values, self.repair_column, row_mask=violated
        )


def repair(
    lhs_or_constraint: Union[Callable, str, BaseConstraint],
    comp: str = None,
    rhs: Union[ConstraintSet, Vector, List] = None,
    name: str = None,
):
    """Repair factory function.
    Constructs a repair function for a set membership constraint.

    Args:
        lhs_or_constraint: left hand side of the constraint.

            - Callable: the partial returned from optimizer.utils.functional.column.
                This cannot be a general callable.
            - str: used to index a passed DataFrame.
            - BaseConstraint: used as the constraint object rather than constructing
                a new one. Note this will be deepcopied before passing to Penalty.

        comp: comparator string, must be "in" for now.
        rhs: right hand side of constraint.

            - ConstraintSet: uses the nearest method of a constraint set.
            - Vector/List: constructs a UserDefinedSet and applies the nearest method.

        name: optional constraint name.

            - Passed to the constraint function.
            - Ignored if a Constraint object is provided.

    Returns:
        Repair object with expected properties.

    Raises:
        ValueError: if lhs is not a string or the partial
            from optimizer.utils.functional.column.
        ValueError: when comp is an comparator other than "in".
    """
    if isinstance(lhs_or_constraint, SetMembershipConstraint):
        constraint_ = deepcopy(lhs_or_constraint)

    elif comp is not None and comp.strip() == "in":
        lhs = (
            column(lhs_or_constraint)
            if isinstance(lhs_or_constraint, str)
            else lhs_or_constraint
        )

        if not hasattr(lhs, "keywords") or "col" not in lhs.keywords:
            raise ValueError(
                "Left hand side of repair must either be a string or the partial "
                "returned by optimizer.utils.functional.column."
            )

        constraint_ = constraint(lhs, comp, rhs, name=name)

    else:
        raise ValueError(
            "Repair can only handle set membership constraints. "
            "Provide a SetMembershipConstraint object or specify your repair with "
            "the 'in' comparator."
        )

    return Repair(
        constraint_,
        constraint_.constraint_set.nearest,
        constraint_.constraint_func.keywords["col"],
    )
