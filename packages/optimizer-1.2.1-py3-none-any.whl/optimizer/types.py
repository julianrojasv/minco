# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""
Holds custom types used throughout the code.
"""

from typing import Union  # pylint: disable=E0611

import numpy as np
import pandas as pd


Vector = Union[np.ndarray, pd.Series]
Matrix = Union[np.ndarray, np.matrix, pd.DataFrame]


class Predictor:
    """
    Static duck type class to represent some object with a predict method.
    """

    def predict(self, parameters: Matrix) -> Vector:  # pylint: disable=W0613
        ...
